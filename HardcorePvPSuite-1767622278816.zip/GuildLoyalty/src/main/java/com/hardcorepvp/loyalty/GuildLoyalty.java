package com.hardcorepvp.loyalty;

import com.hardcorepvp.guilds.HardcoreGuilds;
import com.hardcorepvp.loyalty.data.LoyaltyManager;
import com.hardcorepvp.loyalty.listeners.LoyaltyListener;
import lombok.Getter;
import org.bukkit.plugin.java.JavaPlugin;

public class GuildLoyalty extends JavaPlugin {

    @Getter
    private static GuildLoyalty instance;

    @Getter
    private LoyaltyManager loyaltyManager;

    @Getter
    private HardcoreGuilds guildsPlugin;

    @Override
    public void onEnable() {
        instance = this;

        guildsPlugin = (HardcoreGuilds) getServer().getPluginManager().getPlugin("HardcoreGuilds");
        if (guildsPlugin == null) {
            getLogger().severe("HardcoreGuilds not found!");
            getServer().getPluginManager().disablePlugin(this);
            return;
        }

        saveDefaultConfig();

        this.loyaltyManager = new LoyaltyManager(this);
        this.loyaltyManager.load();

        getServer().getPluginManager().registerEvents(new LoyaltyListener(this), this);

        loyaltyManager.startDecayTask();

        getLogger().info("GuildLoyalty enabled!");
    }

    @Override
    public void onDisable() {
        if (loyaltyManager != null) {
            loyaltyManager.stopDecayTask();
            loyaltyManager.save();
        }
        getLogger().info("GuildLoyalty disabled!");
    }
}