package com.hardcorepvp.loyalty.data;

import com.hardcorepvp.loyalty.GuildLoyalty;
import org.bukkit.Bukkit;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.entity.Player;
import org.bukkit.scheduler.BukkitTask;

import java.io.File;
import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

public class LoyaltyManager {

    private final GuildLoyalty plugin;
    private final Map<UUID, Integer> loyalty;
    private final Map<UUID, Long> lastSeen;
    private BukkitTask decayTask;

    public LoyaltyManager(GuildLoyalty plugin) {
        this.plugin = plugin;
        this.loyalty = new HashMap<>();
        this.lastSeen = new HashMap<>();
    }

    public int getLoyalty(UUID uuid) {
        return loyalty.getOrDefault(uuid, 50);
    }

    public void setLoyalty(UUID uuid, int value) {
        loyalty.put(uuid, Math.max(0, Math.min(100, value)));
    }

    public void addLoyalty(UUID uuid, int amount) {
        setLoyalty(uuid, getLoyalty(uuid) + amount);
    }

    public void onWarParticipation(UUID uuid) {
        addLoyalty(uuid, plugin.getConfig().getInt("loyalty-gain.war-participation", 10));
    }

    public void onChestTheft(UUID uuid) {
        addLoyalty(uuid, -plugin.getConfig().getInt("loyalty-loss.chest-theft", 30));
    }

    public double getBetrayalChance(UUID uuid) {
        int l = getLoyalty(uuid);
        if (l >= 50) return 0.0;

        return (50 - l) / 100.0;
    }

    public void updateLastSeen(UUID uuid) {
        lastSeen.put(uuid, System.currentTimeMillis());
    }

    public void startDecayTask() {
        decayTask = Bukkit.getScheduler().runTaskTimer(plugin, () -> {
            long now = System.currentTimeMillis();
            long inactiveThreshold = plugin.getConfig().getLong("inactivity-threshold", 86400) * 1000L;

            for (UUID uuid : new HashMap<>(lastSeen).keySet()) {
                long last = lastSeen.get(uuid);
                if (now - last > inactiveThreshold) {
                    addLoyalty(uuid, -1);
                }
            }
        }, 72000L, 72000L);
    }

    public void stopDecayTask() {
        if (decayTask != null) {
            decayTask.cancel();
        }
    }

    public void load() {
        File file = new File(plugin.getDataFolder(), "loyalty.yml");
        if (!file.exists()) return;

        YamlConfiguration config = YamlConfiguration.loadConfiguration(file);
        for (String key : config.getKeys(false)) {
            UUID uuid = UUID.fromString(key);
            loyalty.put(uuid, config.getInt(key + ".loyalty"));
            lastSeen.put(uuid, config.getLong(key + ".last-seen"));
        }
    }

    public void save() {
        File file = new File(plugin.getDataFolder(), "loyalty.yml");
        YamlConfiguration config = new YamlConfiguration();

        for (Map.Entry<UUID, Integer> entry : loyalty.entrySet()) {
            config.set(entry.getKey() + ".loyalty", entry.getValue());
            config.set(entry.getKey() + ".last-seen", lastSeen.getOrDefault(entry.getKey(), System.currentTimeMillis()));
        }

        try {
            config.save(file);
        } catch (Exception e) {
            plugin.getLogger().severe("Failed to save loyalty: " + e.getMessage());
        }
    }
}