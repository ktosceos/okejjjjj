package com.hardcorepvp.loyalty.listeners;

import com.hardcorepvp.loyalty.GuildLoyalty;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.player.PlayerJoinEvent;

public class LoyaltyListener implements Listener {

    private final GuildLoyalty plugin;

    public LoyaltyListener(GuildLoyalty plugin) {
        this.plugin = plugin;
    }

    @EventHandler
    public void onJoin(PlayerJoinEvent event) {
        plugin.getLoyaltyManager().updateLastSeen(event.getPlayer().getUniqueId());
    }
}