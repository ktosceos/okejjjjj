package com.hardcorepvp.reputation.data;

import com.hardcorepvp.reputation.PlayerReputation;
import org.bukkit.configuration.file.YamlConfiguration;

import java.io.File;
import java.util.*;
import java.util.stream.Collectors;

public class ReputationManager {

    private final PlayerReputation plugin;
    private final Map<UUID, Integer> reputation;

    public ReputationManager(PlayerReputation plugin) {
        this.plugin = plugin;
        this.reputation = new HashMap<>();
    }

    public void addReputation(UUID uuid, int amount) {
        int current = reputation.getOrDefault(uuid, 0);
        reputation.put(uuid, current + amount);
    }

    public int getReputation(UUID uuid) {
        return reputation.getOrDefault(uuid, 0);
    }

    public String getReputationLevel(UUID uuid) {
        int rep = getReputation(uuid);

        int honorable = plugin.getConfig().getInt("reputation-levels.honorable", 100);
        int infamous = plugin.getConfig().getInt("reputation-levels.infamous", -100);

        if (rep >= honorable) {
            return "§aHonorable";
        } else if (rep <= infamous) {
            return "§cInfamous";
        } else {
            return "§7Neutral";
        }
    }

    public double getTeleportCostMultiplier(UUID uuid) {
        String level = getReputationLevel(uuid).toLowerCase().replace("§a", "").replace("§c", "").replace("§7", "");
        return plugin.getConfig().getDouble("effects.teleport-cost-multiplier." + level, 1.0);
    }

    public double getBountyChanceMultiplier(UUID uuid) {
        String level = getReputationLevel(uuid).toLowerCase().replace("§a", "").replace("§c", "").replace("§7", "");
        return plugin.getConfig().getDouble("effects.bounty-chance-multiplier." + level, 1.0);
    }

    public Map<UUID, Integer> getTopReputation(int limit) {
        return reputation.entrySet().stream()
            .sorted(Map.Entry.<UUID, Integer>comparingByValue().reversed())
            .limit(limit)
            .collect(Collectors.toMap(
                Map.Entry::getKey,
                Map.Entry::getValue,
                (e1, e2) -> e1,
                LinkedHashMap::new
            ));
    }

    public void loadReputation() {
        File file = new File(plugin.getDataFolder(), "reputation.yml");
        if (!file.exists()) {
            return;
        }

        YamlConfiguration config = YamlConfiguration.loadConfiguration(file);

        for (String key : config.getKeys(false)) {
            UUID uuid = UUID.fromString(key);
            int rep = config.getInt(key);
            reputation.put(uuid, rep);
        }

        plugin.getLogger().info("Loaded reputation for " + reputation.size() + " players");
    }

    public void saveReputation() {
        File file = new File(plugin.getDataFolder(), "reputation.yml");
        YamlConfiguration config = new YamlConfiguration();

        for (Map.Entry<UUID, Integer> entry : reputation.entrySet()) {
            config.set(entry.getKey().toString(), entry.getValue());
        }

        try {
            config.save(file);
            plugin.getLogger().info("Saved reputation for " + reputation.size() + " players");
        } catch (Exception e) {
            plugin.getLogger().severe("Failed to save reputation: " + e.getMessage());
        }
    }
}