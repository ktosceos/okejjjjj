package com.hardcorepvp.reputation.listeners;

import com.hardcorepvp.reputation.PlayerReputation;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.PlayerDeathEvent;

public class ReputationListener implements Listener {

    private final PlayerReputation plugin;

    public ReputationListener(PlayerReputation plugin) {
        this.plugin = plugin;
    }

    @EventHandler
    public void onDeath(PlayerDeathEvent event) {
        Player victim = event.getEntity();
        Player killer = victim.getKiller();

        if (killer == null) {
            return;
        }

        int repChange = plugin.getConfig().getInt("reputation-changes.pvp-kill", -10);
        plugin.getReputationManager().addReputation(killer.getUniqueId(), repChange);

        int total = plugin.getReputationManager().getReputation(killer.getUniqueId());
        String message = plugin.getConfig().getString("messages.reputation-changed", "Reputation changed!")
            .replace("&", "§")
            .replace("{change}", String.valueOf(repChange))
            .replace("{total}", String.valueOf(total));

        killer.sendMessage(message);
    }
}