package com.hardcorepvp.reputation.commands;

import com.hardcorepvp.reputation.PlayerReputation;
import org.bukkit.Bukkit;
import org.bukkit.OfflinePlayer;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;

import java.util.Map;
import java.util.UUID;

public class RepCommand implements CommandExecutor {

    private final PlayerReputation plugin;

    public RepCommand(PlayerReputation plugin) {
        this.plugin = plugin;
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (!(sender instanceof Player)) {
            sender.sendMessage("§cOnly players can use this command!");
            return true;
        }

        Player player = (Player) sender;

        if (args.length == 0) {
            int rep = plugin.getReputationManager().getReputation(player.getUniqueId());
            String level = plugin.getReputationManager().getReputationLevel(player.getUniqueId());

            String message = plugin.getConfig().getString("messages.reputation-level", "Reputation: {level}")
                .replace("&", "§")
                .replace("{level}", level)
                .replace("{points}", String.valueOf(rep));

            player.sendMessage(message);
            return true;
        }

        if (args[0].equalsIgnoreCase("top")) {
            Map<UUID, Integer> topRep = plugin.getReputationManager().getTopReputation(10);

            player.sendMessage("§6§l=== Top Reputation ===");
            int rank = 1;
            for (Map.Entry<UUID, Integer> entry : topRep.entrySet()) {
                OfflinePlayer target = Bukkit.getOfflinePlayer(entry.getKey());
                String level = plugin.getReputationManager().getReputationLevel(entry.getKey());
                player.sendMessage("§e" + rank + ". §7" + target.getName() + " §e- " + level + " §7(" + entry.getValue() + ")");
                rank++;
            }
            return true;
        }

        return true;
    }
}