package com.hardcorepvp.reputation;

import com.hardcorepvp.reputation.commands.RepCommand;
import com.hardcorepvp.reputation.data.ReputationManager;
import com.hardcorepvp.reputation.listeners.ReputationListener;
import lombok.Getter;
import org.bukkit.plugin.java.JavaPlugin;

public class PlayerReputation extends JavaPlugin {

    @Getter
    private static PlayerReputation instance;

    @Getter
    private ReputationManager reputationManager;

    @Override
    public void onEnable() {
        instance = this;

        saveDefaultConfig();

        this.reputationManager = new ReputationManager(this);
        this.reputationManager.loadReputation();

        getCommand("rep").setExecutor(new RepCommand(this));

        getServer().getPluginManager().registerEvents(new ReputationListener(this), this);

        getLogger().info("PlayerReputation enabled!");
    }

    @Override
    public void onDisable() {
        if (reputationManager != null) {
            reputationManager.saveReputation();
        }
        getLogger().info("PlayerReputation disabled!");
    }
}