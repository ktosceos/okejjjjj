package com.hardcorepvp.core.listeners;

import com.hardcorepvp.core.HardcorePvPCore;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.EntityDamageByEntityEvent;

public class CombatListener implements Listener {

    private final HardcorePvPCore plugin;

    public CombatListener(HardcorePvPCore plugin) {
        this.plugin = plugin;
    }

    @EventHandler
    public void onDamage(EntityDamageByEntityEvent event) {
        if (!(event.getEntity() instanceof Player)) {
            return;
        }

        if (!(event.getDamager() instanceof Player)) {
            return;
        }

        Player victim = (Player) event.getEntity();
        Player attacker = (Player) event.getDamager();

        if (plugin.getCombatManager().isInSafeZone(victim) || plugin.getCombatManager().isInSafeZone(attacker)) {
            event.setCancelled(true);
            attacker.sendMessage("§cYou cannot attack players in a safe zone!");
            return;
        }

        plugin.getCombatManager().tagPlayer(victim);
        plugin.getCombatManager().tagPlayer(attacker);
    }
}