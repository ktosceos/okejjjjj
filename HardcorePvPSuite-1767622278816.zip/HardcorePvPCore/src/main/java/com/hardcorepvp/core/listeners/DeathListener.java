package com.hardcorepvp.core.listeners;

import com.hardcorepvp.core.HardcorePvPCore;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.PlayerDeathEvent;

public class DeathListener implements Listener {

    private final HardcorePvPCore plugin;

    public DeathListener(HardcorePvPCore plugin) {
        this.plugin = plugin;
    }

    @EventHandler
    public void onDeath(PlayerDeathEvent event) {
        Player player = event.getEntity();

        plugin.getCombatManager().removeCombat(player);

        event.setKeepInventory(false);
        event.setKeepLevel(false);
        event.getDrops().clear();
        event.getDrops().addAll(player.getInventory().getContents().length > 0 ?
            java.util.Arrays.asList(player.getInventory().getContents()) : java.util.Collections.emptyList());
    }
}