package com.hardcorepvp.core;

import com.hardcorepvp.core.combat.CombatManager;
import com.hardcorepvp.core.commands.CombatCommand;
import com.hardcorepvp.core.commands.SpawnCommand;
import com.hardcorepvp.core.listeners.CombatListener;
import com.hardcorepvp.core.listeners.DeathListener;
import com.hardcorepvp.core.listeners.QuitListener;
import lombok.Getter;
import org.bukkit.plugin.java.JavaPlugin;

public class HardcorePvPCore extends JavaPlugin {

    @Getter
    private static HardcorePvPCore instance;

    @Getter
    private CombatManager combatManager;

    @Override
    public void onEnable() {
        instance = this;

        saveDefaultConfig();

        this.combatManager = new CombatManager(this);

        getCommand("spawn").setExecutor(new SpawnCommand(this));
        getCommand("combat").setExecutor(new CombatCommand(this));

        getServer().getPluginManager().registerEvents(new CombatListener(this), this);
        getServer().getPluginManager().registerEvents(new DeathListener(this), this);
        getServer().getPluginManager().registerEvents(new QuitListener(this), this);

        getLogger().info("HardcorePvPCore enabled!");
    }

    @Override
    public void onDisable() {
        getLogger().info("HardcorePvPCore disabled!");
    }
}