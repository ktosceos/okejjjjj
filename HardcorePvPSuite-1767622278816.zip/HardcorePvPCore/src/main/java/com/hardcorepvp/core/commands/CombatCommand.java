package com.hardcorepvp.core.commands;

import com.hardcorepvp.core.HardcorePvPCore;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;

public class CombatCommand implements CommandExecutor {

    private final HardcorePvPCore plugin;

    public CombatCommand(HardcorePvPCore plugin) {
        this.plugin = plugin;
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (!(sender instanceof Player)) {
            sender.sendMessage("§cOnly players can use this command!");
            return true;
        }

        Player player = (Player) sender;

        if (plugin.getCombatManager().isInCombat(player)) {
            int remaining = plugin.getCombatManager().getRemainingTime(player);
            player.sendMessage("§c§lCOMBAT! §7Time remaining: §c" + remaining + "s");
        } else {
            player.sendMessage("§a§lSAFE! §7You are not in combat.");
        }

        return true;
    }
}