package com.hardcorepvp.core.combat;

import com.hardcorepvp.core.HardcorePvPCore;
import org.bukkit.Bukkit;
import org.bukkit.entity.Player;
import org.bukkit.scheduler.BukkitTask;

import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

public class CombatManager {

    private final HardcorePvPCore plugin;
    private final Map<UUID, Long> combatTags;
    private final Map<UUID, BukkitTask> combatTasks;

    public CombatManager(HardcorePvPCore plugin) {
        this.plugin = plugin;
        this.combatTags = new HashMap<>();
        this.combatTasks = new HashMap<>();
    }

    public void tagPlayer(Player player) {
        if (player.hasPermission("hardcore.bypass.combat")) {
            return;
        }

        UUID uuid = player.getUniqueId();
        int duration = plugin.getConfig().getInt("combat-duration", 30);
        long endTime = System.currentTimeMillis() + (duration * 1000L);

        boolean wasInCombat = isInCombat(player);
        combatTags.put(uuid, endTime);

        if (combatTasks.containsKey(uuid)) {
            combatTasks.get(uuid).cancel();
        }

        BukkitTask task = Bukkit.getScheduler().runTaskLater(plugin, () -> {
            combatTags.remove(uuid);
            combatTasks.remove(uuid);

            if (player.isOnline()) {
                String message = plugin.getConfig().getString("messages.combat-exit", "&aYou are no longer in combat.");
                player.sendMessage(message.replace("&", "§"));
            }
        }, duration * 20L);

        combatTasks.put(uuid, task);

        if (!wasInCombat) {
            String message = plugin.getConfig().getString("messages.combat-enter", "&cYou are now in combat!");
            player.sendMessage(message.replace("&", "§").replace("{time}", String.valueOf(duration)));
        }
    }

    public boolean isInCombat(Player player) {
        UUID uuid = player.getUniqueId();
        if (!combatTags.containsKey(uuid)) {
            return false;
        }

        if (System.currentTimeMillis() >= combatTags.get(uuid)) {
            removeCombat(player);
            return false;
        }

        return true;
    }

    public int getRemainingTime(Player player) {
        if (!isInCombat(player)) {
            return 0;
        }

        long remaining = combatTags.get(player.getUniqueId()) - System.currentTimeMillis();
        return (int) Math.ceil(remaining / 1000.0);
    }

    public void removeCombat(Player player) {
        UUID uuid = player.getUniqueId();
        combatTags.remove(uuid);

        if (combatTasks.containsKey(uuid)) {
            combatTasks.get(uuid).cancel();
            combatTasks.remove(uuid);
        }
    }

    public boolean isInSafeZone(Player player) {
        if (!plugin.getConfig().getBoolean("spawn-region.enabled", true)) {
            return false;
        }

        String worldName = plugin.getConfig().getString("spawn-region.world", "world");
        if (!player.getWorld().getName().equals(worldName)) {
            return false;
        }

        int centerX = plugin.getConfig().getInt("spawn-region.x", 0);
        int centerZ = plugin.getConfig().getInt("spawn-region.z", 0);
        int radius = plugin.getConfig().getInt("spawn-region.radius", 50);

        double distanceSquared = Math.pow(player.getLocation().getX() - centerX, 2) +
                                Math.pow(player.getLocation().getZ() - centerZ, 2);

        return distanceSquared <= radius * radius;
    }
}