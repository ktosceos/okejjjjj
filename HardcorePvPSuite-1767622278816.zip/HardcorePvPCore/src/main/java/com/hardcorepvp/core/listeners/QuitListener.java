package com.hardcorepvp.core.listeners;

import com.hardcorepvp.core.HardcorePvPCore;
import org.bukkit.Bukkit;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.player.PlayerQuitEvent;

public class QuitListener implements Listener {

    private final HardcorePvPCore plugin;

    public QuitListener(HardcorePvPCore plugin) {
        this.plugin = plugin;
    }

    @EventHandler
    public void onQuit(PlayerQuitEvent event) {
        Player player = event.getPlayer();

        if (plugin.getCombatManager().isInCombat(player)) {
            player.setHealth(0);

            String message = plugin.getConfig().getString("messages.combat-logout", "{player} logged out during combat and died!");
            Bukkit.broadcastMessage(message.replace("&", "§").replace("{player}", player.getName()));

            plugin.getCombatManager().removeCombat(player);
        }
    }
}