package com.hardcorepvp.core.commands;

import com.hardcorepvp.core.HardcorePvPCore;
import org.bukkit.Location;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;

public class SpawnCommand implements CommandExecutor {

    private final HardcorePvPCore plugin;

    public SpawnCommand(HardcorePvPCore plugin) {
        this.plugin = plugin;
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (!(sender instanceof Player)) {
            sender.sendMessage("§cOnly players can use this command!");
            return true;
        }

        Player player = (Player) sender;

        if (plugin.getCombatManager().isInCombat(player)) {
            int remaining = plugin.getCombatManager().getRemainingTime(player);
            String message = plugin.getConfig().getString("messages.combat-active", "&cYou cannot teleport while in combat!");
            player.sendMessage(message.replace("&", "§").replace("{time}", String.valueOf(remaining)));
            return true;
        }

        String worldName = plugin.getConfig().getString("spawn-region.world", "world");
        int x = plugin.getConfig().getInt("spawn-region.x", 0);
        int y = plugin.getConfig().getInt("spawn-region.y", 64);
        int z = plugin.getConfig().getInt("spawn-region.z", 0);

        Location spawn = new Location(plugin.getServer().getWorld(worldName), x + 0.5, y, z + 0.5);
        player.teleport(spawn);

        String message = plugin.getConfig().getString("messages.spawn-teleport", "&aTeleporting to spawn...");
        player.sendMessage(message.replace("&", "§"));

        return true;
    }
}