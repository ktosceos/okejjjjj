package com.hardcorepvp.wars.data;

import com.hardcorepvp.wars.GuildWars;
import org.bukkit.Bukkit;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.configuration.file.YamlConfiguration;

import java.io.File;
import java.util.*;

public class WarManager {

    private final GuildWars plugin;
    private final List<War> activeWars;
    private final Map<String, Long> warCooldowns;
    private final Map<String, Integer> guildRankings;

    public WarManager(GuildWars plugin) {
        this.plugin = plugin;
        this.activeWars = new ArrayList<>();
        this.warCooldowns = new HashMap<>();
        this.guildRankings = new HashMap<>();
    }

    public War declareWar(String attacker, String defender) {
        long duration = plugin.getConfig().getLong("wars.duration", 86400);
        War war = new War(attacker, defender, duration);
        activeWars.add(war);

        String message = plugin.getConfig().getString("messages.war-declared", "");
        Bukkit.broadcastMessage(message.replace("&", "§")
            .replace("{attacker}", attacker)
            .replace("{defender}", defender));

        return war;
    }

    public void endWar(War war) {
        war.setActive(false);
        activeWars.remove(war);

        String winner = war.getWinner();
        int points = 0;

        if (winner != null) {
            points = war.getPoints(winner);
            addRankingPoints(winner, points);

            if (plugin.getProgressionPlugin() != null) {
                plugin.getProgressionPlugin().getProgressionManager().addExperience(winner, points * 2);
            }
        }

        long cooldown = plugin.getConfig().getLong("wars.cooldown", 172800);
        warCooldowns.put(war.getAttacker().toLowerCase(), System.currentTimeMillis() + (cooldown * 1000L));
        warCooldowns.put(war.getDefender().toLowerCase(), System.currentTimeMillis() + (cooldown * 1000L));

        String message = plugin.getConfig().getString("messages.war-ended", "");
        Bukkit.broadcastMessage(message.replace("&", "§")
            .replace("{winner}", winner != null ? winner : "Draw")
            .replace("{points}", String.valueOf(points)));
    }

    public War getWar(String guild1, String guild2) {
        for (War war : activeWars) {
            if ((war.getAttacker().equalsIgnoreCase(guild1) && war.getDefender().equalsIgnoreCase(guild2)) ||
                (war.getAttacker().equalsIgnoreCase(guild2) && war.getDefender().equalsIgnoreCase(guild1))) {
                return war;
            }
        }
        return null;
    }

    public War getGuildWar(String guild) {
        for (War war : activeWars) {
            if (war.isInvolved(guild)) {
                return war;
            }
        }
        return null;
    }

    public boolean isAtWar(String guild1, String guild2) {
        return getWar(guild1, guild2) != null;
    }

    public boolean hasCooldown(String guild) {
        Long endTime = warCooldowns.get(guild.toLowerCase());
        if (endTime == null) {
            return false;
        }

        if (System.currentTimeMillis() >= endTime) {
            warCooldowns.remove(guild.toLowerCase());
            return false;
        }

        return true;
    }

    public long getCooldownRemaining(String guild) {
        Long endTime = warCooldowns.get(guild.toLowerCase());
        if (endTime == null) {
            return 0;
        }

        return (endTime - System.currentTimeMillis()) / 1000;
    }

    public void addRankingPoints(String guild, int points) {
        guildRankings.put(guild.toLowerCase(), guildRankings.getOrDefault(guild.toLowerCase(), 0) + points);
    }

    public Map<String, Integer> getTopGuilds(int limit) {
        return guildRankings.entrySet().stream()
            .sorted(Map.Entry.<String, Integer>comparingByValue().reversed())
            .limit(limit)
            .collect(LinkedHashMap::new, (m, e) -> m.put(e.getKey(), e.getValue()), LinkedHashMap::putAll);
    }

    public void checkExpiredWars() {
        List<War> toEnd = new ArrayList<>();

        for (War war : activeWars) {
            if (System.currentTimeMillis() >= war.getEndTime()) {
                toEnd.add(war);
            }
        }

        for (War war : toEnd) {
            endWar(war);
        }
    }

    public void load() {
        File file = new File(plugin.getDataFolder(), "wars.yml");
        if (!file.exists()) {
            return;
        }

        YamlConfiguration config = YamlConfiguration.loadConfiguration(file);

        ConfigurationSection warsSection = config.getConfigurationSection("active-wars");
        if (warsSection != null) {
            for (String key : warsSection.getKeys(false)) {
                String attacker = warsSection.getString(key + ".attacker");
                String defender = warsSection.getString(key + ".defender");
                long startTime = warsSection.getLong(key + ".start-time");
                long endTime = warsSection.getLong(key + ".end-time");

                War war = new War(attacker, defender, 0);
                war.setStartTime(startTime);
                war.setEndTime(endTime);

                ConfigurationSection pointsSection = warsSection.getConfigurationSection(key + ".points");
                if (pointsSection != null) {
                    for (String guild : pointsSection.getKeys(false)) {
                        war.getPoints().put(guild, pointsSection.getInt(guild));
                    }
                }

                activeWars.add(war);
            }
        }

        ConfigurationSection rankingsSection = config.getConfigurationSection("rankings");
        if (rankingsSection != null) {
            for (String guild : rankingsSection.getKeys(false)) {
                guildRankings.put(guild, rankingsSection.getInt(guild));
            }
        }

        plugin.getLogger().info("Loaded " + activeWars.size() + " active wars");
    }

    public void save() {
        File file = new File(plugin.getDataFolder(), "wars.yml");
        YamlConfiguration config = new YamlConfiguration();

        int index = 0;
        for (War war : activeWars) {
            String path = "active-wars." + index;
            config.set(path + ".attacker", war.getAttacker());
            config.set(path + ".defender", war.getDefender());
            config.set(path + ".start-time", war.getStartTime());
            config.set(path + ".end-time", war.getEndTime());

            for (Map.Entry<String, Integer> entry : war.getPoints().entrySet()) {
                config.set(path + ".points." + entry.getKey(), entry.getValue());
            }

            index++;
        }

        for (Map.Entry<String, Integer> entry : guildRankings.entrySet()) {
            config.set("rankings." + entry.getKey(), entry.getValue());
        }

        try {
            config.save(file);
            plugin.getLogger().info("Saved " + activeWars.size() + " active wars");
        } catch (Exception e) {
            plugin.getLogger().severe("Failed to save wars: " + e.getMessage());
        }
    }

    public List<War> getActiveWars() {
        return new ArrayList<>(activeWars);
    }
}