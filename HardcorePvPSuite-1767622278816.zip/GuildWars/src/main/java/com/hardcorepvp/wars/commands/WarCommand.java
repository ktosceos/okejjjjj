package com.hardcorepvp.wars.commands;

import com.hardcorepvp.guilds.data.Guild;
import com.hardcorepvp.wars.GuildWars;
import com.hardcorepvp.wars.data.War;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;

import java.util.Map;

public class WarCommand implements CommandExecutor {

    private final GuildWars plugin;

    public WarCommand(GuildWars plugin) {
        this.plugin = plugin;
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (!(sender instanceof Player)) {
            return true;
        }

        Player player = (Player) sender;

        if (args.length < 2) {
            return false;
        }

        if (!args[0].equalsIgnoreCase("war")) {
            return false;
        }

        switch (args[1].toLowerCase()) {
            case "declare":
                handleDeclare(player, args);
                break;
            case "accept":
                handleAccept(player);
                break;
            case "status":
                handleStatus(player);
                break;
            case "top":
                handleTop(player);
                break;
            default:
                return false;
        }

        return true;
    }

    private void handleDeclare(Player player, String[] args) {
        if (args.length < 3) {
            player.sendMessage("§cUsage: /g war declare <guild>");
            return;
        }

        Guild attackerGuild = plugin.getGuildsPlugin().getGuildManager().getPlayerGuild(player.getUniqueId());
        if (attackerGuild == null) {
            player.sendMessage("§cYou are not in a guild!");
            return;
        }

        if (!attackerGuild.isLeader(player.getUniqueId())) {
            player.sendMessage("§cOnly the guild leader can declare war!");
            return;
        }

        Guild defenderGuild = plugin.getGuildsPlugin().getGuildManager().getGuild(args[2]);
        if (defenderGuild == null) {
            player.sendMessage("§cGuild not found!");
            return;
        }

        if (attackerGuild.getName().equalsIgnoreCase(defenderGuild.getName())) {
            player.sendMessage("§cYou cannot declare war on your own guild!");
            return;
        }

        if (plugin.getWarManager().getGuildWar(attackerGuild.getName()) != null) {
            player.sendMessage("§cYour guild is already at war!");
            return;
        }

        if (plugin.getWarManager().hasCooldown(attackerGuild.getName())) {
            long remaining = plugin.getWarManager().getCooldownRemaining(attackerGuild.getName());
            player.sendMessage("§cYour guild has a war cooldown! Remaining: §e" + (remaining / 3600) + "h");
            return;
        }

        plugin.getWarManager().declareWar(attackerGuild.getName(), defenderGuild.getName());
    }

    private void handleAccept(Player player) {
        Guild guild = plugin.getGuildsPlugin().getGuildManager().getPlayerGuild(player.getUniqueId());
        if (guild == null) {
            player.sendMessage("§cYou are not in a guild!");
            return;
        }

        if (!guild.isLeader(player.getUniqueId())) {
            player.sendMessage("§cOnly the guild leader can accept wars!");
            return;
        }

        War war = plugin.getWarManager().getGuildWar(guild.getName());
        if (war == null) {
            player.sendMessage("§cYour guild has no pending war declarations!");
            return;
        }

        if (!war.getDefender().equalsIgnoreCase(guild.getName())) {
            player.sendMessage("§cYour guild is the attacker, not the defender!");
            return;
        }

        String message = plugin.getConfig().getString("messages.war-accepted", "");
        org.bukkit.Bukkit.broadcastMessage(message.replace("&", "§")
            .replace("{defender}", war.getDefender())
            .replace("{attacker}", war.getAttacker()));
    }

    private void handleStatus(Player player) {
        Guild guild = plugin.getGuildsPlugin().getGuildManager().getPlayerGuild(player.getUniqueId());
        if (guild == null) {
            player.sendMessage("§cYou are not in a guild!");
            return;
        }

        War war = plugin.getWarManager().getGuildWar(guild.getName());
        if (war == null) {
            player.sendMessage("§cYour guild is not at war!");
            return;
        }

        long remaining = (war.getEndTime() - System.currentTimeMillis()) / 1000;

        player.sendMessage("§c§l=== War Status ===");
        player.sendMessage("§7Attacker: §e" + war.getAttacker() + " §7(§e" + war.getPoints(war.getAttacker()) + " pts§7)");
        player.sendMessage("§7Defender: §e" + war.getDefender() + " §7(§e" + war.getPoints(war.getDefender()) + " pts§7)");
        player.sendMessage("§7Time Remaining: §e" + (remaining / 3600) + "h " + ((remaining % 3600) / 60) + "m");
    }

    private void handleTop(Player player) {
        Map<String, Integer> topGuilds = plugin.getWarManager().getTopGuilds(10);

        player.sendMessage("§6§l=== Top Guilds ===");
        int rank = 1;
        for (Map.Entry<String, Integer> entry : topGuilds.entrySet()) {
            player.sendMessage("§e#" + rank + " §7" + entry.getKey() + " §7- §e" + entry.getValue() + " points");
            rank++;
        }
    }
}