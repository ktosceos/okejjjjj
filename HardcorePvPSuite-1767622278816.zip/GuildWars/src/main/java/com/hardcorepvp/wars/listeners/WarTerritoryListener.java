package com.hardcorepvp.wars.listeners;

import com.hardcorepvp.guilds.data.Guild;
import com.hardcorepvp.wars.GuildWars;
import com.hardcorepvp.wars.data.War;
import org.bukkit.block.Block;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.block.BlockBreakEvent;
import org.bukkit.event.player.PlayerMoveEvent;

import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

public class WarTerritoryListener implements Listener {

    private final GuildWars plugin;
    private final Map<UUID, String> lastTerritory;

    public WarTerritoryListener(GuildWars plugin) {
        this.plugin = plugin;
        this.lastTerritory = new HashMap<>();
    }

    @EventHandler
    public void onMove(PlayerMoveEvent event) {
        if (event.getFrom().getBlockX() == event.getTo().getBlockX() &&
            event.getFrom().getBlockZ() == event.getTo().getBlockZ()) {
            return;
        }

        Player player = event.getPlayer();
        Guild playerGuild = plugin.getGuildsPlugin().getGuildManager().getPlayerGuild(player.getUniqueId());

        if (playerGuild == null) {
            return;
        }

        for (Guild guild : plugin.getGuildsPlugin().getGuildManager().getAllGuilds()) {
            if (guild.getBase() == null) {
                continue;
            }

            if (guild.getName().equalsIgnoreCase(playerGuild.getName())) {
                continue;
            }

            War war = plugin.getWarManager().getWar(playerGuild.getName(), guild.getName());
            if (war == null) {
                continue;
            }

            int radius = 50;
            double distance = player.getLocation().distance(guild.getBase());

            if (distance <= radius) {
                String last = lastTerritory.get(player.getUniqueId());
                if (!guild.getName().equalsIgnoreCase(last)) {
                    lastTerritory.put(player.getUniqueId(), guild.getName());

                    String message = plugin.getConfig().getString("messages.enemy-territory", "");
                    player.sendMessage(message.replace("&", "§"));
                }
                return;
            }
        }

        lastTerritory.remove(player.getUniqueId());
    }

    @EventHandler
    public void onBlockBreak(BlockBreakEvent event) {
        Player player = event.getPlayer();
        Block block = event.getBlock();

        Guild playerGuild = plugin.getGuildsPlugin().getGuildManager().getPlayerGuild(player.getUniqueId());
        if (playerGuild == null) {
            return;
        }

        for (Guild guild : plugin.getGuildsPlugin().getGuildManager().getAllGuilds()) {
            if (guild.getBase() == null) {
                continue;
            }

            if (guild.getName().equalsIgnoreCase(playerGuild.getName())) {
                continue;
            }

            War war = plugin.getWarManager().getWar(playerGuild.getName(), guild.getName());
            if (war == null) {
                continue;
            }

            int radius = 50;
            double distance = block.getLocation().distance(guild.getBase());

            if (distance <= radius) {
                int points = plugin.getConfig().getInt("points.block-break", 1);
                war.addPoints(playerGuild.getName(), points);

                String message = plugin.getConfig().getString("messages.break-points", "");
                player.sendMessage(message.replace("&", "§").replace("{points}", String.valueOf(points)));
            }
        }
    }
}