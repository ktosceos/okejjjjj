package com.hardcorepvp.wars;

import com.hardcorepvp.guilds.HardcoreGuilds;
import com.hardcorepvp.progression.GuildProgression;
import com.hardcorepvp.wars.commands.WarCommand;
import com.hardcorepvp.wars.data.WarManager;
import com.hardcorepvp.wars.listeners.WarCombatListener;
import com.hardcorepvp.wars.listeners.WarTerritoryListener;
import lombok.Getter;
import org.bukkit.plugin.java.JavaPlugin;

public class GuildWars extends JavaPlugin {

    @Getter
    private static GuildWars instance;

    @Getter
    private WarManager warManager;

    @Getter
    private HardcoreGuilds guildsPlugin;

    @Getter
    private GuildProgression progressionPlugin;

    @Override
    public void onEnable() {
        instance = this;

        guildsPlugin = (HardcoreGuilds) getServer().getPluginManager().getPlugin("HardcoreGuilds");
        if (guildsPlugin == null) {
            getLogger().severe("HardcoreGuilds not found! Disabling plugin.");
            getServer().getPluginManager().disablePlugin(this);
            return;
        }

        progressionPlugin = (GuildProgression) getServer().getPluginManager().getPlugin("GuildProgression");

        saveDefaultConfig();

        this.warManager = new WarManager(this);
        this.warManager.load();

        getCommand("g").setExecutor(new WarCommand(this));

        getServer().getPluginManager().registerEvents(new WarCombatListener(this), this);
        getServer().getPluginManager().registerEvents(new WarTerritoryListener(this), this);

        getServer().getScheduler().runTaskTimer(this, () -> {
            warManager.checkExpiredWars();
        }, 1200L, 1200L);

        getLogger().info("GuildWars enabled!");
    }

    @Override
    public void onDisable() {
        if (warManager != null) {
            warManager.save();
        }
        getLogger().info("GuildWars disabled!");
    }
}