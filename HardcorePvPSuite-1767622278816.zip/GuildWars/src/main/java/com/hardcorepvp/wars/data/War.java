package com.hardcorepvp.wars.data;

import lombok.Data;

import java.util.HashMap;
import java.util.Map;

@Data
public class War {
    private String attacker;
    private String defender;
    private Map<String, Integer> points;
    private long startTime;
    private long endTime;
    private boolean active;

    public War(String attacker, String defender, long duration) {
        this.attacker = attacker;
        this.defender = defender;
        this.points = new HashMap<>();
        this.points.put(attacker, 0);
        this.points.put(defender, 0);
        this.startTime = System.currentTimeMillis();
        this.endTime = startTime + (duration * 1000L);
        this.active = true;
    }

    public void addPoints(String guild, int amount) {
        points.put(guild, points.getOrDefault(guild, 0) + amount);
    }

    public int getPoints(String guild) {
        return points.getOrDefault(guild, 0);
    }

    public String getWinner() {
        int attackerPoints = getPoints(attacker);
        int defenderPoints = getPoints(defender);

        if (attackerPoints > defenderPoints) {
            return attacker;
        } else if (defenderPoints > attackerPoints) {
            return defender;
        }

        return null;
    }

    public boolean isInvolved(String guild) {
        return attacker.equalsIgnoreCase(guild) || defender.equalsIgnoreCase(guild);
    }

    public String getOpponent(String guild) {
        if (attacker.equalsIgnoreCase(guild)) {
            return defender;
        } else if (defender.equalsIgnoreCase(guild)) {
            return attacker;
        }
        return null;
    }
}