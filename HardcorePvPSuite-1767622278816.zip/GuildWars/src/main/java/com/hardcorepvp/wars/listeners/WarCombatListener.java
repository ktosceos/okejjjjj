package com.hardcorepvp.wars.listeners;

import com.hardcorepvp.guilds.data.Guild;
import com.hardcorepvp.wars.GuildWars;
import com.hardcorepvp.wars.data.War;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.PlayerDeathEvent;

public class WarCombatListener implements Listener {

    private final GuildWars plugin;

    public WarCombatListener(GuildWars plugin) {
        this.plugin = plugin;
    }

    @EventHandler
    public void onKill(PlayerDeathEvent event) {
        Player victim = event.getEntity();
        Player killer = victim.getKiller();

        if (killer == null) {
            return;
        }

        Guild victimGuild = plugin.getGuildsPlugin().getGuildManager().getPlayerGuild(victim.getUniqueId());
        Guild killerGuild = plugin.getGuildsPlugin().getGuildManager().getPlayerGuild(killer.getUniqueId());

        if (victimGuild == null || killerGuild == null) {
            return;
        }

        War war = plugin.getWarManager().getWar(victimGuild.getName(), killerGuild.getName());
        if (war == null) {
            return;
        }

        int points = plugin.getConfig().getInt("points.player-kill", 10);
        war.addPoints(killerGuild.getName(), points);

        String message = plugin.getConfig().getString("messages.kill-points", "");
        killer.sendMessage(message.replace("&", "§")
            .replace("{points}", String.valueOf(points))
            .replace("{victim}", victim.getName()));

        if (plugin.getProgressionPlugin() != null) {
            int warExp = plugin.getProgressionPlugin().getConfig().getInt("experience.war-kill", 100);
            plugin.getProgressionPlugin().getProgressionManager().addExperience(killerGuild.getName(), warExp);
        }
    }
}