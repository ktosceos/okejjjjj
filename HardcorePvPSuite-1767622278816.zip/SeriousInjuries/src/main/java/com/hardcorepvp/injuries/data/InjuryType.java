package com.hardcorepvp.injuries.data;

public enum InjuryType {
    BROKEN_ARM,
    BROKEN_LEG,
    CONCUSSION
}