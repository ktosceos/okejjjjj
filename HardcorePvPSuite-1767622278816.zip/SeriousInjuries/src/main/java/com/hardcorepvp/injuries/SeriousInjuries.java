package com.hardcorepvp.injuries;

import com.hardcorepvp.injuries.data.InjuryManager;
import com.hardcorepvp.injuries.listeners.InjuryListener;
import lombok.Getter;
import org.bukkit.plugin.java.JavaPlugin;

public class SeriousInjuries extends JavaPlugin {

    @Getter
    private static SeriousInjuries instance;

    @Getter
    private InjuryManager injuryManager;

    @Override
    public void onEnable() {
        instance = this;

        saveDefaultConfig();

        this.injuryManager = new InjuryManager(this);
        this.injuryManager.load();

        getServer().getPluginManager().registerEvents(new InjuryListener(this), this);

        injuryManager.startHealingTask();

        getLogger().info("SeriousInjuries enabled!");
    }

    @Override
    public void onDisable() {
        if (injuryManager != null) {
            injuryManager.stopHealingTask();
            injuryManager.save();
        }
        getLogger().info("SeriousInjuries disabled!");
    }
}