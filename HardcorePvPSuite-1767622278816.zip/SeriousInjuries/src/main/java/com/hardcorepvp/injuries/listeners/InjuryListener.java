package com.hardcorepvp.injuries.listeners;

import com.hardcorepvp.injuries.SeriousInjuries;
import com.hardcorepvp.injuries.data.InjuryType;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.EntityDamageEvent;
import org.bukkit.event.player.PlayerJoinEvent;

public class InjuryListener implements Listener {

    private final SeriousInjuries plugin;

    public InjuryListener(SeriousInjuries plugin) {
        this.plugin = plugin;
    }

    @EventHandler
    public void onDamage(EntityDamageEvent event) {
        if (!(event.getEntity() instanceof Player)) return;

        Player player = (Player) event.getEntity();
        double healthPercent = player.getHealth() / player.getMaxHealth();

        if (healthPercent > 0.3) return;

        double chance = plugin.getConfig().getDouble("injury-chance", 0.2);
        if (Math.random() > chance) return;

        InjuryType[] types = InjuryType.values();
        InjuryType type = types[(int) (Math.random() * types.length)];

        int severity = healthPercent < 0.15 ? 2 : 1;

        plugin.getInjuryManager().addInjury(player.getUniqueId(), type, severity);
    }

    @EventHandler
    public void onJoin(PlayerJoinEvent event) {
        plugin.getInjuryManager().applyEffects(event.getPlayer());
    }
}