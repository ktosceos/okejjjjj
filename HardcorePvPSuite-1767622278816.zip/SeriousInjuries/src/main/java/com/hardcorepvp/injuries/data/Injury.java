package com.hardcorepvp.injuries.data;

import lombok.AllArgsConstructor;
import lombok.Data;

@Data
@AllArgsConstructor
public class Injury {
    private InjuryType type;
    private long healTime;
    private int severity;
}