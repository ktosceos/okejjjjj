package com.hardcorepvp.injuries.data;

import com.cryptomorin.xseries.XPotion;
import com.hardcorepvp.injuries.SeriousInjuries;
import org.bukkit.Bukkit;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.entity.Player;
import org.bukkit.scheduler.BukkitTask;

import java.io.File;
import java.util.*;

public class InjuryManager {

    private final SeriousInjuries plugin;
    private final Map<UUID, List<Injury>> injuries;
    private BukkitTask healingTask;

    public InjuryManager(SeriousInjuries plugin) {
        this.plugin = plugin;
        this.injuries = new HashMap<>();
    }

    public void addInjury(UUID uuid, InjuryType type, int severity) {
        injuries.putIfAbsent(uuid, new ArrayList<>());

        long healTime = System.currentTimeMillis() + (plugin.getConfig().getLong("heal-time." + type.name().toLowerCase(), 3600) * 1000L);
        injuries.get(uuid).add(new Injury(type, healTime, severity));

        Player player = Bukkit.getPlayer(uuid);
        if (player != null) {
            player.sendMessage("§c§lYou suffered a " + type.name().replace("_", " ") + "!");
        }
    }

    public List<Injury> getInjuries(UUID uuid) {
        return injuries.getOrDefault(uuid, new ArrayList<>());
    }

    public boolean hasInjury(UUID uuid, InjuryType type) {
        return getInjuries(uuid).stream().anyMatch(i -> i.getType() == type);
    }

    public void applyEffects(Player player) {
        List<Injury> playerInjuries = getInjuries(player.getUniqueId());

        for (Injury injury : playerInjuries) {
            switch (injury.getType()) {
                case BROKEN_ARM:
                    XPotion.matchXPotion("SLOW_DIGGING")
                        .map(xp -> xp.buildPotionEffect(100, injury.getSeverity()))
                        .ifPresent(player::addPotionEffect);
                    break;
                case BROKEN_LEG:
                    XPotion.matchXPotion("SLOW")
                        .map(xp -> xp.buildPotionEffect(100, injury.getSeverity()))
                        .ifPresent(player::addPotionEffect);
                    player.setWalkSpeed(0.1f);
                    break;
                case CONCUSSION:
                    XPotion.matchXPotion("CONFUSION")
                        .map(xp -> xp.buildPotionEffect(100, 0))
                        .ifPresent(player::addPotionEffect);
                    break;
            }
        }
    }

    public void startHealingTask() {
        healingTask = Bukkit.getScheduler().runTaskTimer(plugin, () -> {
            long now = System.currentTimeMillis();

            for (UUID uuid : new HashMap<>(injuries).keySet()) {
                List<Injury> playerInjuries = injuries.get(uuid);
                playerInjuries.removeIf(injury -> now >= injury.getHealTime());

                if (playerInjuries.isEmpty()) {
                    injuries.remove(uuid);
                    Player player = Bukkit.getPlayer(uuid);
                    if (player != null) {
                        player.sendMessage("§aYour injuries have healed!");
                        player.setWalkSpeed(0.2f);
                    }
                }
            }
        }, 100L, 100L);
    }

    public void stopHealingTask() {
        if (healingTask != null) {
            healingTask.cancel();
        }
    }

    public void load() {
        File file = new File(plugin.getDataFolder(), "injuries.yml");
        if (!file.exists()) return;

        YamlConfiguration config = YamlConfiguration.loadConfiguration(file);
        ConfigurationSection section = config.getConfigurationSection("injuries");
        if (section == null) return;

        for (String key : section.getKeys(false)) {
            UUID uuid = UUID.fromString(key);
            List<Injury> list = new ArrayList<>();

            ConfigurationSection playerSection = section.getConfigurationSection(key);
            for (String injuryKey : playerSection.getKeys(false)) {
                InjuryType type = InjuryType.valueOf(playerSection.getString(injuryKey + ".type"));
                long healTime = playerSection.getLong(injuryKey + ".heal-time");
                int severity = playerSection.getInt(injuryKey + ".severity");
                list.add(new Injury(type, healTime, severity));
            }

            injuries.put(uuid, list);
        }
    }

    public void save() {
        File file = new File(plugin.getDataFolder(), "injuries.yml");
        YamlConfiguration config = new YamlConfiguration();

        for (Map.Entry<UUID, List<Injury>> entry : injuries.entrySet()) {
            int index = 0;
            for (Injury injury : entry.getValue()) {
                String path = "injuries." + entry.getKey() + "." + index;
                config.set(path + ".type", injury.getType().name());
                config.set(path + ".heal-time", injury.getHealTime());
                config.set(path + ".severity", injury.getSeverity());
                index++;
            }
        }

        try {
            config.save(file);
        } catch (Exception e) {
            plugin.getLogger().severe("Failed to save injuries: " + e.getMessage());
        }
    }
}