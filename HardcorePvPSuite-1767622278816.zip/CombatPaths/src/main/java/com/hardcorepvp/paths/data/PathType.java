package com.hardcorepvp.paths.data;

public enum PathType {
    BERSERKER,
    SABOTEUR,
    DEFENDER,
    HUNTER
}