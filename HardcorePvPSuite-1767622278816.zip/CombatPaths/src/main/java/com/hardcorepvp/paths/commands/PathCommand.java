package com.hardcorepvp.paths.commands;

import com.hardcorepvp.paths.CombatPaths;
import com.hardcorepvp.paths.data.PathType;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;

public class PathCommand implements CommandExecutor {

    private final CombatPaths plugin;

    public PathCommand(CombatPaths plugin) {
        this.plugin = plugin;
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (!(sender instanceof Player)) return true;

        Player player = (Player) sender;

        if (args.length == 0) {
            PathType current = plugin.getPathManager().getPath(player.getUniqueId());
            if (current == null) {
                player.sendMessage("§cYou have no combat path selected!");
                player.sendMessage("§7Choose: /path <berserker|saboteur|defender|hunter>");
            } else {
                int level = plugin.getPathManager().getLevel(player.getUniqueId());
                player.sendMessage("§6Path: §e" + current.name() + " §7(Level " + level + ")");
            }
            return true;
        }

        try {
            PathType path = PathType.valueOf(args[0].toUpperCase());
            plugin.getPathManager().setPath(player.getUniqueId(), path);
            player.sendMessage("§aYou have chosen the " + path.name() + " path!");
        } catch (IllegalArgumentException e) {
            player.sendMessage("§cInvalid path! Choose: berserker, saboteur, defender, hunter");
        }

        return true;
    }
}