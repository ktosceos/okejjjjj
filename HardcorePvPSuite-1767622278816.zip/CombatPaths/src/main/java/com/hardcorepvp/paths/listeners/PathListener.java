package com.hardcorepvp.paths.listeners;

import com.hardcorepvp.paths.CombatPaths;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.EntityDamageByEntityEvent;
import org.bukkit.event.player.PlayerInteractEvent;

public class PathListener implements Listener {

    private final CombatPaths plugin;

    public PathListener(CombatPaths plugin) {
        this.plugin = plugin;
    }

    @EventHandler
    public void onDamage(EntityDamageByEntityEvent event) {
        if (!(event.getDamager() instanceof Player)) return;
        if (!(event.getEntity() instanceof Player)) return;

        Player attacker = (Player) event.getDamager();
        Player victim = (Player) event.getEntity();

        double multiplier = plugin.getPathManager().getDamageMultiplier(attacker.getUniqueId(), victim.getUniqueId());
        event.setDamage(event.getDamage() * multiplier);
    }

    @EventHandler
    public void onInteract(PlayerInteractEvent event) {
        if (!event.getAction().name().contains("RIGHT")) return;
        if (!event.getPlayer().isSneaking()) return;

        Player player = event.getPlayer();
        if (player.getInventory().getItemInMainHand().getType().name().contains("SWORD")) {
            plugin.getPathManager().useAbility(player);
        }
    }
}