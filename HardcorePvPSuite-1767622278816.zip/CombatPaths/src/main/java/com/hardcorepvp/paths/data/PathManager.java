package com.hardcorepvp.paths.data;

import com.cryptomorin.xseries.XPotion;
import com.hardcorepvp.paths.CombatPaths;
import org.bukkit.Bukkit;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.entity.Player;

import java.io.File;
import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

public class PathManager {

    private final CombatPaths plugin;
    private final Map<UUID, PathType> paths;
    private final Map<UUID, Integer> pathLevels;
    private final Map<UUID, Long> abilityCooldowns;

    public PathManager(CombatPaths plugin) {
        this.plugin = plugin;
        this.paths = new HashMap<>();
        this.pathLevels = new HashMap<>();
        this.abilityCooldowns = new HashMap<>();
    }

    public PathType getPath(UUID uuid) {
        return paths.get(uuid);
    }

    public void setPath(UUID uuid, PathType path) {
        paths.put(uuid, path);
        pathLevels.put(uuid, 1);
    }

    public int getLevel(UUID uuid) {
        return pathLevels.getOrDefault(uuid, 1);
    }

    public void addExperience(UUID uuid, int amount) {
        int level = getLevel(uuid);
        pathLevels.put(uuid, level + (amount / 100));
    }

    public boolean canUseAbility(UUID uuid) {
        Long cooldown = abilityCooldowns.get(uuid);
        if (cooldown == null) return true;

        return System.currentTimeMillis() >= cooldown;
    }

    public void useAbility(Player player) {
        PathType path = getPath(player.getUniqueId());
        if (path == null) return;

        if (!canUseAbility(player.getUniqueId())) {
            player.sendMessage("§cAbility on cooldown!");
            return;
        }

        switch (path) {
            case BERSERKER:
                XPotion.matchXPotion("INCREASE_DAMAGE")
                    .map(xp -> xp.buildPotionEffect(200, 1))
                    .ifPresent(player::addPotionEffect);
                XPotion.matchXPotion("DAMAGE_RESISTANCE")
                    .map(xp -> xp.buildPotionEffect(200, 0))
                    .ifPresent(player::addPotionEffect);
                player.sendMessage("§c§lBERSERKER RAGE!");
                break;
            case SABOTEUR:
                XPotion.matchXPotion("INVISIBILITY")
                    .map(xp -> xp.buildPotionEffect(100, 0))
                    .ifPresent(player::addPotionEffect);
                XPotion.matchXPotion("SPEED")
                    .map(xp -> xp.buildPotionEffect(100, 1))
                    .ifPresent(player::addPotionEffect);
                player.sendMessage("§8§lSHADOW STEP!");
                break;
            case DEFENDER:
                XPotion.matchXPotion("DAMAGE_RESISTANCE")
                    .map(xp -> xp.buildPotionEffect(300, 2))
                    .ifPresent(player::addPotionEffect);
                XPotion.matchXPotion("REGENERATION")
                    .map(xp -> xp.buildPotionEffect(200, 1))
                    .ifPresent(player::addPotionEffect);
                player.sendMessage("§9§lFORTIFY!");
                break;
            case HUNTER:
                XPotion.matchXPotion("SPEED")
                    .map(xp -> xp.buildPotionEffect(200, 2))
                    .ifPresent(player::addPotionEffect);
                XPotion.matchXPotion("JUMP")
                    .map(xp -> xp.buildPotionEffect(200, 1))
                    .ifPresent(player::addPotionEffect);
                player.sendMessage("§a§lHUNT!");
                break;
        }

        abilityCooldowns.put(player.getUniqueId(), System.currentTimeMillis() + 60000);
    }

    public double getDamageMultiplier(UUID attacker, UUID victim) {
        PathType attackerPath = getPath(attacker);
        PathType victimPath = getPath(victim);

        if (attackerPath == null || victimPath == null) return 1.0;

        if (attackerPath == PathType.BERSERKER && victimPath == PathType.SABOTEUR) return 1.3;
        if (attackerPath == PathType.SABOTEUR && victimPath == PathType.DEFENDER) return 1.3;
        if (attackerPath == PathType.DEFENDER && victimPath == PathType.HUNTER) return 1.3;
        if (attackerPath == PathType.HUNTER && victimPath == PathType.BERSERKER) return 1.3;

        return 1.0;
    }

    public void load() {
        File file = new File(plugin.getDataFolder(), "paths.yml");
        if (!file.exists()) return;

        YamlConfiguration config = YamlConfiguration.loadConfiguration(file);
        for (String key : config.getKeys(false)) {
            UUID uuid = UUID.fromString(key);
            paths.put(uuid, PathType.valueOf(config.getString(key + ".path")));
            pathLevels.put(uuid, config.getInt(key + ".level", 1));
        }
    }

    public void save() {
        File file = new File(plugin.getDataFolder(), "paths.yml");
        YamlConfiguration config = new YamlConfiguration();

        for (Map.Entry<UUID, PathType> entry : paths.entrySet()) {
            config.set(entry.getKey() + ".path", entry.getValue().name());
            config.set(entry.getKey() + ".level", pathLevels.getOrDefault(entry.getKey(), 1));
        }

        try {
            config.save(file);
        } catch (Exception e) {
            plugin.getLogger().severe("Failed to save paths: " + e.getMessage());
        }
    }
}