package com.hardcorepvp.paths;

import com.hardcorepvp.paths.commands.PathCommand;
import com.hardcorepvp.paths.data.PathManager;
import com.hardcorepvp.paths.listeners.PathListener;
import lombok.Getter;
import org.bukkit.plugin.java.JavaPlugin;

public class CombatPaths extends JavaPlugin {

    @Getter
    private static CombatPaths instance;

    @Getter
    private PathManager pathManager;

    @Override
    public void onEnable() {
        instance = this;

        saveDefaultConfig();

        this.pathManager = new PathManager(this);
        this.pathManager.load();

        getCommand("path").setExecutor(new PathCommand(this));

        getServer().getPluginManager().registerEvents(new PathListener(this), this);

        getLogger().info("CombatPaths enabled!");
    }

    @Override
    public void onDisable() {
        if (pathManager != null) {
            pathManager.save();
        }
        getLogger().info("CombatPaths disabled!");
    }
}