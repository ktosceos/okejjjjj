package com.hardcorepvp.teleport.listeners;

import com.cryptomorin.xseries.XMaterial;
import com.hardcorepvp.core.HardcorePvPCore;
import com.hardcorepvp.guilds.HardcoreGuilds;
import com.hardcorepvp.guilds.data.Guild;
import com.hardcorepvp.teleport.HardcoreTeleport;
import org.bukkit.Bukkit;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.player.PlayerInteractEvent;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;

public class TeleportItemListener implements Listener {

    private final HardcoreTeleport plugin;
    private final Map<UUID, Long> cooldowns;

    public TeleportItemListener(HardcoreTeleport plugin) {
        this.plugin = plugin;
        this.cooldowns = new HashMap<>();
    }

    @EventHandler
    public void onInteract(PlayerInteractEvent event) {
        if (!event.hasItem()) {
            return;
        }

        Player player = event.getPlayer();
        ItemStack item = event.getItem();

        if (!isTeleportItem(item)) {
            return;
        }

        event.setCancelled(true);

        HardcorePvPCore corePlugin = (HardcorePvPCore) Bukkit.getPluginManager().getPlugin("HardcorePvPCore");
        if (corePlugin != null && corePlugin.getCombatManager().isInCombat(player)) {
            player.sendMessage("§cYou cannot use this item while in combat!");
            return;
        }

        if (cooldowns.containsKey(player.getUniqueId())) {
            long remaining = (cooldowns.get(player.getUniqueId()) - System.currentTimeMillis()) / 1000;
            if (remaining > 0) {
                player.sendMessage("§cCooldown: §e" + remaining + "s");
                return;
            }
        }

        HardcoreGuilds guildsPlugin = (HardcoreGuilds) Bukkit.getPluginManager().getPlugin("HardcoreGuilds");
        if (guildsPlugin == null) {
            return;
        }

        Guild guild = guildsPlugin.getGuildManager().getPlayerGuild(player.getUniqueId());
        if (guild == null || guild.getBase() == null) {
            player.sendMessage("§cYour guild has no base set!");
            return;
        }

        ItemMeta meta = item.getItemMeta();
        if (meta == null || !meta.hasLore()) {
            return;
        }

        List<String> lore = meta.getLore();
        int uses = getUsesFromLore(lore);

        if (uses <= 0) {
            player.sendMessage(plugin.getConfig().getString("messages.item-depleted", "").replace("&", "§"));
            return;
        }

        player.teleport(guild.getBase());

        uses--;
        setUsesInLore(lore, uses);
        meta.setLore(lore);
        item.setItemMeta(meta);

        int cooldown = plugin.getConfig().getInt("items.cooldown", 600);
        cooldowns.put(player.getUniqueId(), System.currentTimeMillis() + (cooldown * 1000L));

        String message = plugin.getConfig().getString("messages.item-used", "");
        player.sendMessage(message.replace("&", "§").replace("{uses}", String.valueOf(uses)));
    }

    private boolean isTeleportItem(ItemStack item) {
        if (item == null || !item.hasItemMeta()) {
            return false;
        }

        ItemMeta meta = item.getItemMeta();
        if (!meta.hasDisplayName()) {
            return false;
        }

        return meta.getDisplayName().contains("Teleport");
    }

    private int getUsesFromLore(List<String> lore) {
        for (String line : lore) {
            if (line.contains("Uses:")) {
                String[] parts = line.split(":");
                if (parts.length > 1) {
                    try {
                        return Integer.parseInt(parts[1].trim().replaceAll("[^0-9]", ""));
                    } catch (NumberFormatException e) {
                        return 0;
                    }
                }
            }
        }
        return 0;
    }

    private void setUsesInLore(List<String> lore, int uses) {
        for (int i = 0; i < lore.size(); i++) {
            if (lore.get(i).contains("Uses:")) {
                lore.set(i, "§7Uses: §e" + uses);
                return;
            }
        }
    }
}