package com.hardcorepvp.teleport;

import com.hardcorepvp.teleport.listeners.TeleportItemListener;
import lombok.Getter;
import org.bukkit.plugin.java.JavaPlugin;

public class HardcoreTeleport extends JavaPlugin {

    @Getter
    private static HardcoreTeleport instance;

    @Override
    public void onEnable() {
        instance = this;

        saveDefaultConfig();

        getServer().getPluginManager().registerEvents(new TeleportItemListener(this), this);

        getLogger().info("HardcoreTeleport enabled!");
    }

    @Override
    public void onDisable() {
        getLogger().info("HardcoreTeleport disabled!");
    }
}