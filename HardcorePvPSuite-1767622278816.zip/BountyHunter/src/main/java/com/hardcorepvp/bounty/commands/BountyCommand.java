package com.hardcorepvp.bounty.commands;

import com.hardcorepvp.bounty.BountyHunter;
import org.bukkit.Bukkit;
import org.bukkit.OfflinePlayer;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;

import java.util.Map;
import java.util.UUID;

public class BountyCommand implements CommandExecutor {

    private final BountyHunter plugin;

    public BountyCommand(BountyHunter plugin) {
        this.plugin = plugin;
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (!(sender instanceof Player)) {
            sender.sendMessage("§cOnly players can use this command!");
            return true;
        }

        Player player = (Player) sender;

        if (args.length == 0) {
            sendHelp(player);
            return true;
        }

        switch (args[0].toLowerCase()) {
            case "set":
                handleSet(player, args);
                break;
            case "add":
                handleAdd(player, args);
                break;
            case "list":
                handleList(player);
                break;
            case "claim":
                player.sendMessage("§aBounties are automatically claimed when you kill a player!");
                break;
            default:
                sendHelp(player);
        }

        return true;
    }

    private void handleSet(Player player, String[] args) {
        if (args.length < 3) {
            player.sendMessage("§cUsage: /bounty set <player> <amount>");
            return;
        }

        OfflinePlayer target = Bukkit.getOfflinePlayer(args[1]);

        if (target.getUniqueId().equals(player.getUniqueId())) {
            player.sendMessage(msg("cannot-self"));
            return;
        }

        double amount;
        try {
            amount = Double.parseDouble(args[2]);
        } catch (NumberFormatException e) {
            player.sendMessage("§cInvalid amount!");
            return;
        }

        double minBounty = plugin.getConfig().getDouble("min-bounty", 100);
        double maxBounty = plugin.getConfig().getDouble("max-bounty", 1000000);

        if (amount < minBounty || amount > maxBounty) {
            player.sendMessage("§cBounty must be between $" + minBounty + " and $" + maxBounty + "!");
            return;
        }

        if (plugin.getEconomy().getBalance(player) < amount) {
            player.sendMessage(msg("insufficient-funds").replace("{amount}", String.valueOf(amount)));
            return;
        }

        plugin.getEconomy().withdrawPlayer(player, amount);
        plugin.getBountyManager().setBounty(target.getUniqueId(), amount);

        String message = msg("bounty-set")
            .replace("{player}", player.getName())
            .replace("{target}", target.getName())
            .replace("{amount}", String.valueOf(amount));

        double threshold = plugin.getConfig().getDouble("top-announce-threshold", 10000);
        if (amount >= threshold) {
            Bukkit.broadcastMessage(message);
        } else {
            player.sendMessage(message);
        }
    }

    private void handleAdd(Player player, String[] args) {
        if (args.length < 3) {
            player.sendMessage("§cUsage: /bounty add <player> <amount>");
            return;
        }

        OfflinePlayer target = Bukkit.getOfflinePlayer(args[1]);

        if (target.getUniqueId().equals(player.getUniqueId())) {
            player.sendMessage(msg("cannot-self"));
            return;
        }

        double amount;
        try {
            amount = Double.parseDouble(args[2]);
        } catch (NumberFormatException e) {
            player.sendMessage("§cInvalid amount!");
            return;
        }

        if (plugin.getEconomy().getBalance(player) < amount) {
            player.sendMessage(msg("insufficient-funds").replace("{amount}", String.valueOf(amount)));
            return;
        }

        plugin.getEconomy().withdrawPlayer(player, amount);
        plugin.getBountyManager().addBounty(target.getUniqueId(), amount);

        player.sendMessage(msg("bounty-added")
            .replace("{target}", target.getName())
            .replace("{amount}", String.valueOf(amount)));
    }

    private void handleList(Player player) {
        Map<UUID, Double> bounties = plugin.getBountyManager().getTopBounties(10);

        if (bounties.isEmpty()) {
            player.sendMessage("§cNo active bounties!");
            return;
        }

        player.sendMessage("§6§l=== Top Bounties ===");
        int rank = 1;
        for (Map.Entry<UUID, Double> entry : bounties.entrySet()) {
            OfflinePlayer target = Bukkit.getOfflinePlayer(entry.getKey());
            player.sendMessage("§e" + rank + ". §7" + target.getName() + " §e- §c$" + entry.getValue());
            rank++;
        }
    }

    private void sendHelp(Player player) {
        player.sendMessage("§6§l=== Bounty Commands ===");
        player.sendMessage("§e/bounty set <player> <amount> §7- Set a bounty");
        player.sendMessage("§e/bounty add <player> <amount> §7- Add to existing bounty");
        player.sendMessage("§e/bounty list §7- View top bounties");
        player.sendMessage("§e/bounty claim §7- Info about claiming");
    }

    private String msg(String key) {
        return plugin.getConfig().getString("messages." + key, "&c" + key).replace("&", "§");
    }
}