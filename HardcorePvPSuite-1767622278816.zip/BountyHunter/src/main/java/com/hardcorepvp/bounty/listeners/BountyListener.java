package com.hardcorepvp.bounty.listeners;

import com.hardcorepvp.bounty.BountyHunter;
import com.hardcorepvp.guilds.HardcoreGuilds;
import com.hardcorepvp.guilds.data.Guild;
import org.bukkit.Bukkit;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.PlayerDeathEvent;

public class BountyListener implements Listener {

    private final BountyHunter plugin;

    public BountyListener(BountyHunter plugin) {
        this.plugin = plugin;
    }

    @EventHandler
    public void onDeath(PlayerDeathEvent event) {
        Player victim = event.getEntity();
        Player killer = victim.getKiller();

        if (killer == null) {
            return;
        }

        if (!plugin.getBountyManager().hasBounty(victim.getUniqueId())) {
            return;
        }

        if (killer.getUniqueId().equals(victim.getUniqueId())) {
            return;
        }

        HardcoreGuilds guildsPlugin = (HardcoreGuilds) Bukkit.getPluginManager().getPlugin("HardcoreGuilds");
        if (guildsPlugin != null) {
            Guild victimGuild = guildsPlugin.getGuildManager().getPlayerGuild(victim.getUniqueId());
            Guild killerGuild = guildsPlugin.getGuildManager().getPlayerGuild(killer.getUniqueId());

            if (victimGuild != null && killerGuild != null && victimGuild.equals(killerGuild)) {
                return;
            }
        }

        double bounty = plugin.getBountyManager().claimBounty(victim.getUniqueId());
        plugin.getEconomy().depositPlayer(killer, bounty);

        String message = plugin.getConfig().getString("messages.bounty-claimed", "Bounty claimed!")
            .replace("&", "§")
            .replace("{killer}", killer.getName())
            .replace("{target}", victim.getName())
            .replace("{amount}", String.valueOf(bounty));

        Bukkit.broadcastMessage(message);
    }
}