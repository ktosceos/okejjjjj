package com.hardcorepvp.bounty;

import com.hardcorepvp.bounty.commands.BountyCommand;
import com.hardcorepvp.bounty.data.BountyManager;
import com.hardcorepvp.bounty.listeners.BountyListener;
import lombok.Getter;
import net.milkbowl.vault.economy.Economy;
import org.bukkit.plugin.RegisteredServiceProvider;
import org.bukkit.plugin.java.JavaPlugin;

public class BountyHunter extends JavaPlugin {

    @Getter
    private static BountyHunter instance;

    @Getter
    private BountyManager bountyManager;

    @Getter
    private Economy economy;

    @Override
    public void onEnable() {
        instance = this;

        if (!setupEconomy()) {
            getLogger().severe("Vault not found! Disabling plugin.");
            getServer().getPluginManager().disablePlugin(this);
            return;
        }

        saveDefaultConfig();

        this.bountyManager = new BountyManager(this);
        this.bountyManager.loadBounties();

        getCommand("bounty").setExecutor(new BountyCommand(this));

        getServer().getPluginManager().registerEvents(new BountyListener(this), this);

        getLogger().info("BountyHunter enabled!");
    }

    @Override
    public void onDisable() {
        if (bountyManager != null) {
            bountyManager.saveBounties();
        }
        getLogger().info("BountyHunter disabled!");
    }

    private boolean setupEconomy() {
        if (getServer().getPluginManager().getPlugin("Vault") == null) {
            return false;
        }

        RegisteredServiceProvider<Economy> rsp = getServer().getServicesManager().getRegistration(Economy.class);
        if (rsp == null) {
            return false;
        }

        economy = rsp.getProvider();
        return economy != null;
    }
}