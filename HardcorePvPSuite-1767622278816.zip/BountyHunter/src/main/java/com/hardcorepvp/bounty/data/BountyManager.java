package com.hardcorepvp.bounty.data;

import com.hardcorepvp.bounty.BountyHunter;
import org.bukkit.configuration.file.YamlConfiguration;

import java.io.File;
import java.util.*;
import java.util.stream.Collectors;

public class BountyManager {

    private final BountyHunter plugin;
    private final Map<UUID, Double> bounties;

    public BountyManager(BountyHunter plugin) {
        this.plugin = plugin;
        this.bounties = new HashMap<>();
    }

    public void setBounty(UUID uuid, double amount) {
        bounties.put(uuid, amount);
    }

    public void addBounty(UUID uuid, double amount) {
        bounties.put(uuid, bounties.getOrDefault(uuid, 0.0) + amount);
    }

    public double getBounty(UUID uuid) {
        return bounties.getOrDefault(uuid, 0.0);
    }

    public boolean hasBounty(UUID uuid) {
        return bounties.containsKey(uuid) && bounties.get(uuid) > 0;
    }

    public double claimBounty(UUID uuid) {
        return bounties.remove(uuid);
    }

    public Map<UUID, Double> getTopBounties(int limit) {
        return bounties.entrySet().stream()
            .sorted(Map.Entry.<UUID, Double>comparingByValue().reversed())
            .limit(limit)
            .collect(Collectors.toMap(
                Map.Entry::getKey,
                Map.Entry::getValue,
                (e1, e2) -> e1,
                LinkedHashMap::new
            ));
    }

    public void loadBounties() {
        File file = new File(plugin.getDataFolder(), "bounties.yml");
        if (!file.exists()) {
            return;
        }

        YamlConfiguration config = YamlConfiguration.loadConfiguration(file);

        for (String key : config.getKeys(false)) {
            UUID uuid = UUID.fromString(key);
            double amount = config.getDouble(key);
            bounties.put(uuid, amount);
        }

        plugin.getLogger().info("Loaded " + bounties.size() + " bounties");
    }

    public void saveBounties() {
        File file = new File(plugin.getDataFolder(), "bounties.yml");
        YamlConfiguration config = new YamlConfiguration();

        for (Map.Entry<UUID, Double> entry : bounties.entrySet()) {
            config.set(entry.getKey().toString(), entry.getValue());
        }

        try {
            config.save(file);
            plugin.getLogger().info("Saved " + bounties.size() + " bounties");
        } catch (Exception e) {
            plugin.getLogger().severe("Failed to save bounties: " + e.getMessage());
        }
    }
}