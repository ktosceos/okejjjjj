package com.hardcorepvp.airdrops;

import com.hardcorepvp.airdrops.commands.AirdropCommand;
import com.hardcorepvp.airdrops.data.AirdropManager;
import com.hardcorepvp.airdrops.listeners.AirdropListener;
import lombok.Getter;
import org.bukkit.plugin.java.JavaPlugin;

public class WorldAirdrops extends JavaPlugin {

    @Getter
    private static WorldAirdrops instance;

    @Getter
    private AirdropManager airdropManager;

    @Override
    public void onEnable() {
        instance = this;

        saveDefaultConfig();

        this.airdropManager = new AirdropManager(this);

        getCommand("airdrop").setExecutor(new AirdropCommand(this));

        getServer().getPluginManager().registerEvents(new AirdropListener(this), this);

        airdropManager.startAutoSpawn();

        getLogger().info("WorldAirdrops enabled!");
    }

    @Override
    public void onDisable() {
        if (airdropManager != null) {
            airdropManager.stopAutoSpawn();
        }
        getLogger().info("WorldAirdrops disabled!");
    }
}