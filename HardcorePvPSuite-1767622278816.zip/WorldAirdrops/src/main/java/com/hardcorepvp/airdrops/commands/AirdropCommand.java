package com.hardcorepvp.airdrops.commands;

import com.hardcorepvp.airdrops.WorldAirdrops;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;

public class AirdropCommand implements CommandExecutor {

    private final WorldAirdrops plugin;

    public AirdropCommand(WorldAirdrops plugin) {
        this.plugin = plugin;
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (args.length == 0) {
            sender.sendMessage("§cUsage: /airdrop <info|start>");
            return true;
        }

        if (args[0].equalsIgnoreCase("info")) {
            sender.sendMessage("§6§l=== Airdrop Info ===");
            sender.sendMessage("§7Active airdrops: §e" + plugin.getAirdropManager().getActiveAirdrops().size());
            sender.sendMessage("§7Next spawn: §e" + plugin.getAirdropManager().getTimeUntilNext() + "s");
            return true;
        }

        if (args[0].equalsIgnoreCase("start")) {
            if (!sender.hasPermission("airdrop.admin")) {
                sender.sendMessage("§cNo permission!");
                return true;
            }

            if (args.length < 2) {
                sender.sendMessage("§cUsage: /airdrop start <type>");
                return true;
            }

            String type = args[1];
            if (!plugin.getConfig().contains("types." + type)) {
                sender.sendMessage("§cInvalid type! Available: common, rare, legendary");
                return true;
            }

            plugin.getAirdropManager().spawnAirdrop(type);
            sender.sendMessage("§aAirdrop spawned!");
            return true;
        }

        return true;
    }
}