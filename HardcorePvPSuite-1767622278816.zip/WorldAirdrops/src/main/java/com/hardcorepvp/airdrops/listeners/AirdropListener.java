package com.hardcorepvp.airdrops.listeners;

import com.hardcorepvp.airdrops.WorldAirdrops;
import com.hardcorepvp.airdrops.data.Airdrop;
import org.bukkit.Material;
import org.bukkit.block.Block;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.block.Action;
import org.bukkit.event.player.PlayerInteractEvent;

public class AirdropListener implements Listener {

    private final WorldAirdrops plugin;

    public AirdropListener(WorldAirdrops plugin) {
        this.plugin = plugin;
    }

    @EventHandler
    public void onInteract(PlayerInteractEvent event) {
        if (event.getAction() != Action.RIGHT_CLICK_BLOCK) {
            return;
        }

        Block block = event.getClickedBlock();
        if (block == null || block.getType() != Material.CHEST) {
            return;
        }

        Airdrop airdrop = plugin.getAirdropManager().getAirdropAt(block.getLocation());
        if (airdrop == null) {
            return;
        }

        Player player = event.getPlayer();

        if (airdrop.isOpened()) {
            return;
        }

        event.setCancelled(true);

        if (plugin.getAirdropManager().isOpening(player)) {
            return;
        }

        plugin.getAirdropManager().startOpening(player, airdrop);
    }
}