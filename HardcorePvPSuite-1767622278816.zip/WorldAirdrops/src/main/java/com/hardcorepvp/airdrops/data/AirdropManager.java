package com.hardcorepvp.airdrops.data;

import com.cryptomorin.xseries.XMaterial;
import com.cryptomorin.xseries.particles.XParticle;
import com.hardcorepvp.airdrops.WorldAirdrops;
import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.World;
import org.bukkit.block.Block;
import org.bukkit.block.Chest;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;
import org.bukkit.scheduler.BukkitTask;

import java.util.*;
import java.util.concurrent.ThreadLocalRandom;

public class AirdropManager {

    private final WorldAirdrops plugin;
    private final List<Airdrop> activeAirdrops;
    private final Map<UUID, AirdropOpening> openingPlayers;
    private BukkitTask autoSpawnTask;
    private long nextSpawnTime;

    public AirdropManager(WorldAirdrops plugin) {
        this.plugin = plugin;
        this.activeAirdrops = new ArrayList<>();
        this.openingPlayers = new HashMap<>();
    }

    public void startAutoSpawn() {
        int interval = plugin.getConfig().getInt("spawn-interval", 1800);
        nextSpawnTime = System.currentTimeMillis() + (interval * 1000L);

        autoSpawnTask = Bukkit.getScheduler().runTaskTimer(plugin, () -> {
            if (System.currentTimeMillis() >= nextSpawnTime) {
                spawnRandomAirdrop();
                nextSpawnTime = System.currentTimeMillis() + (interval * 1000L);
            }
        }, 20L, 20L);
    }

    public void stopAutoSpawn() {
        if (autoSpawnTask != null) {
            autoSpawnTask.cancel();
        }
    }

    public void spawnRandomAirdrop() {
        String type = selectRandomType();
        spawnAirdrop(type);
    }

    public void spawnAirdrop(String type) {
        World world = Bukkit.getWorlds().get(0);
        Location location = findRandomLocation(world);

        if (location == null) {
            return;
        }

        List<ItemStack> loot = generateLoot(type);

        announceAirdrop(location);

        Bukkit.getScheduler().runTaskLater(plugin, () -> {
            Block block = location.getBlock();
            block.setType(Material.CHEST);

            Chest chest = (Chest) block.getState();
            for (int i = 0; i < Math.min(loot.size(), 27); i++) {
                chest.getInventory().setItem(i, loot.get(i));
            }

            Airdrop airdrop = new Airdrop(type, location, block, loot, System.currentTimeMillis());
            activeAirdrops.add(airdrop);

            announceAirdropLanded(location);

            spawnParticles(location);
        }, 100L);
    }

    private String selectRandomType() {
        List<String> types = new ArrayList<>();
        List<Integer> weights = new ArrayList<>();

        for (String type : plugin.getConfig().getConfigurationSection("types").getKeys(false)) {
            boolean nightOnly = plugin.getConfig().getBoolean("types." + type + ".night-only", false);

            if (nightOnly) {
                World world = Bukkit.getWorlds().get(0);
                long time = world.getTime();
                if (time < 13000 || time > 23000) {
                    continue;
                }
            }

            types.add(type);
            weights.add(plugin.getConfig().getInt("types." + type + ".weight", 10));
        }

        int totalWeight = weights.stream().mapToInt(Integer::intValue).sum();
        int random = ThreadLocalRandom.current().nextInt(totalWeight);

        int currentWeight = 0;
        for (int i = 0; i < types.size(); i++) {
            currentWeight += weights.get(i);
            if (random < currentWeight) {
                return types.get(i);
            }
        }

        return types.get(0);
    }

    private Location findRandomLocation(World world) {
        for (int i = 0; i < 10; i++) {
            int x = ThreadLocalRandom.current().nextInt(-1000, 1000);
            int z = ThreadLocalRandom.current().nextInt(-1000, 1000);
            int y = world.getHighestBlockYAt(x, z) + 1;

            Location loc = new Location(world, x, y, z);
            if (loc.getBlock().getType() == Material.AIR) {
                return loc;
            }
        }
        return null;
    }

    private List<ItemStack> generateLoot(String type) {
        List<ItemStack> loot = new ArrayList<>();
        List<String> lootConfig = plugin.getConfig().getStringList("types." + type + ".loot");

        for (String lootEntry : lootConfig) {
            String[] parts = lootEntry.split(":");
            String materialName = parts[0];

            XMaterial xMaterial = XMaterial.matchXMaterial(materialName).orElse(XMaterial.STONE);
            ItemStack item = xMaterial.parseItem();

            if (parts.length > 1) {
                String[] range = parts[1].split("-");
                int min = Integer.parseInt(range[0]);
                int max = range.length > 1 ? Integer.parseInt(range[1]) : min;
                int amount = ThreadLocalRandom.current().nextInt(min, max + 1);
                item.setAmount(amount);
            }

            loot.add(item);
        }

        return loot;
    }

    private void announceAirdrop(Location location) {
        String message = plugin.getConfig().getString("messages.airdrop-incoming", "Airdrop incoming!")
            .replace("&", "§")
            .replace("{x}", String.valueOf(location.getBlockX()))
            .replace("{y}", String.valueOf(location.getBlockY()))
            .replace("{z}", String.valueOf(location.getBlockZ()));

        Bukkit.broadcastMessage(message);
    }

    private void announceAirdropLanded(Location location) {
        String message = plugin.getConfig().getString("messages.airdrop-landed", "Airdrop landed!")
            .replace("&", "§")
            .replace("{x}", String.valueOf(location.getBlockX()))
            .replace("{y}", String.valueOf(location.getBlockY()))
            .replace("{z}", String.valueOf(location.getBlockZ()));

        Bukkit.broadcastMessage(message);
    }

    private void spawnParticles(Location location) {
        Bukkit.getScheduler().runTaskTimer(plugin, task -> {
            Airdrop airdrop = getAirdropAt(location);
            if (airdrop == null || airdrop.isOpened()) {
                task.cancel();
                return;
            }

            XParticle.of("FLAME").ifPresent(p ->
                location.getWorld().spawnParticle(p.get(), location.clone().add(0.5, 1, 0.5), 10, 0.3, 0.3, 0.3, 0.01)
            );
        }, 0L, 20L);
    }

    public void startOpening(Player player, Airdrop airdrop) {
        int openTime = plugin.getConfig().getInt("types." + airdrop.getType() + ".open-time", 5);
        Location startLocation = player.getLocation().clone();

        AirdropOpening opening = new AirdropOpening(airdrop, startLocation, openTime);
        openingPlayers.put(player.getUniqueId(), opening);

        BukkitTask task = Bukkit.getScheduler().runTaskTimer(plugin, () -> {
            if (!openingPlayers.containsKey(player.getUniqueId())) {
                return;
            }

            if (player.getLocation().distance(startLocation) > 1.0) {
                cancelOpening(player);
                return;
            }

            opening.decrementTime();

            if (opening.getTimeRemaining() <= 0) {
                finishOpening(player, airdrop);
            } else {
                String message = plugin.getConfig().getString("messages.opening", "Opening...")
                    .replace("&", "§")
                    .replace("{time}", String.valueOf(opening.getTimeRemaining()));
                player.sendMessage(message);
            }
        }, 0L, 20L);

        opening.setTask(task);
    }

    private void cancelOpening(Player player) {
        AirdropOpening opening = openingPlayers.remove(player.getUniqueId());
        if (opening != null && opening.getTask() != null) {
            opening.getTask().cancel();
            String message = plugin.getConfig().getString("messages.cancelled", "Cancelled!")
                .replace("&", "§");
            player.sendMessage(message);
        }
    }

    private void finishOpening(Player player, Airdrop airdrop) {
        AirdropOpening opening = openingPlayers.remove(player.getUniqueId());
        if (opening != null && opening.getTask() != null) {
            opening.getTask().cancel();
        }

        airdrop.setOpened(true);

        String message = plugin.getConfig().getString("messages.opened", "Opened!")
            .replace("&", "§");
        player.sendMessage(message);
    }

    public Airdrop getAirdropAt(Location location) {
        for (Airdrop airdrop : activeAirdrops) {
            if (airdrop.getLocation().getBlock().equals(location.getBlock())) {
                return airdrop;
            }
        }
        return null;
    }

    public boolean isOpening(Player player) {
        return openingPlayers.containsKey(player.getUniqueId());
    }

    public List<Airdrop> getActiveAirdrops() {
        return activeAirdrops;
    }

    public long getTimeUntilNext() {
        return Math.max(0, (nextSpawnTime - System.currentTimeMillis()) / 1000);
    }

    @lombok.Data
    private static class AirdropOpening {
        private final Airdrop airdrop;
        private final Location startLocation;
        private int timeRemaining;
        private BukkitTask task;

        public AirdropOpening(Airdrop airdrop, Location startLocation, int time) {
            this.airdrop = airdrop;
            this.startLocation = startLocation;
            this.timeRemaining = time;
        }

        public void decrementTime() {
            timeRemaining--;
        }
    }
}