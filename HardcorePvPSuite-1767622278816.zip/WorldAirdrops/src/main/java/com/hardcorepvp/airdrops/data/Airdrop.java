package com.hardcorepvp.airdrops.data;

import lombok.Data;
import org.bukkit.Location;
import org.bukkit.block.Block;
import org.bukkit.inventory.ItemStack;

import java.util.List;

@Data
public class Airdrop {
    private final String type;
    private final Location location;
    private final Block chest;
    private final List<ItemStack> loot;
    private final long spawnTime;
    private boolean opened;
}