package com.hardcorepvp.fatigue.data;

import com.hardcorepvp.core.HardcorePvPCore;
import com.hardcorepvp.fatigue.CombatFatigue;
import com.hardcorepvp.guilds.HardcoreGuilds;
import com.hardcorepvp.guilds.data.Guild;
import org.bukkit.Bukkit;
import org.bukkit.entity.Player;
import org.bukkit.scheduler.BukkitTask;

import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

public class FatigueManager {

    private final CombatFatigue plugin;
    private final Map<UUID, Integer> fatigueLevels;
    private BukkitTask decayTask;

    public FatigueManager(CombatFatigue plugin) {
        this.plugin = plugin;
        this.fatigueLevels = new HashMap<>();
    }

    public void addFatigue(UUID uuid, int amount) {
        int current = fatigueLevels.getOrDefault(uuid, 0);
        int max = plugin.getConfig().getInt("max-fatigue", 100);
        fatigueLevels.put(uuid, Math.min(current + amount, max));

        Player player = Bukkit.getPlayer(uuid);
        if (player != null && fatigueLevels.get(uuid) >= 75) {
            String message = plugin.getConfig().getString("messages.fatigue-high", "Exhausted!")
                .replace("&", "§");
            player.sendMessage(message);
        }
    }

    public int getFatigue(UUID uuid) {
        return fatigueLevels.getOrDefault(uuid, 0);
    }

    public void resetFatigue(UUID uuid) {
        fatigueLevels.remove(uuid);

        Player player = Bukkit.getPlayer(uuid);
        if (player != null) {
            String message = plugin.getConfig().getString("messages.fatigue-reset", "Refreshed!")
                .replace("&", "§");
            player.sendMessage(message);
        }
    }

    public double getRegenMultiplier(UUID uuid) {
        int fatigue = getFatigue(uuid);

        if (fatigue >= 50) {
            return plugin.getConfig().getDouble("effects.50.slower-regen", 0.5);
        }

        return 1.0;
    }

    public double getCooldownMultiplier(UUID uuid) {
        int fatigue = getFatigue(uuid);

        if (fatigue >= 75) {
            return plugin.getConfig().getDouble("effects.75.cooldown-delay", 1.2);
        }

        return 1.0;
    }

    public double getDamageMultiplier(UUID uuid) {
        int fatigue = getFatigue(uuid);

        if (fatigue >= 100) {
            return plugin.getConfig().getDouble("effects.100.damage-multiplier", 1.5);
        }

        return 1.0;
    }

    public void startDecayTask() {
        int interval = plugin.getConfig().getInt("fatigue-decay-interval", 20);
        int decayRate = plugin.getConfig().getInt("fatigue-decay-rate", 1);

        decayTask = Bukkit.getScheduler().runTaskTimer(plugin, () -> {
            for (UUID uuid : new HashMap<>(fatigueLevels).keySet()) {
                Player player = Bukkit.getPlayer(uuid);
                if (player == null) {
                    fatigueLevels.remove(uuid);
                    continue;
                }

                HardcorePvPCore corePlugin = HardcorePvPCore.getInstance();
                if (corePlugin != null && corePlugin.getCombatManager().isInCombat(player)) {
                    continue;
                }

                if (plugin.getConfig().getBoolean("guild-base-reset", true)) {
                    HardcoreGuilds guildsPlugin = (HardcoreGuilds) Bukkit.getPluginManager().getPlugin("HardcoreGuilds");
                    if (guildsPlugin != null) {
                        Guild guild = guildsPlugin.getGuildManager().getPlayerGuild(uuid);
                        if (guild != null && guild.getBase() != null) {
                            if (player.getLocation().distance(guild.getBase()) < 10) {
                                resetFatigue(uuid);
                                continue;
                            }
                        }
                    }
                }

                if (plugin.getConfig().getBoolean("safe-zone-reset", true)) {
                    if (corePlugin != null && corePlugin.getCombatManager().isInSafeZone(player)) {
                        resetFatigue(uuid);
                        continue;
                    }
                }

                int current = fatigueLevels.get(uuid);
                int newValue = Math.max(0, current - decayRate);

                if (newValue == 0) {
                    fatigueLevels.remove(uuid);
                } else {
                    fatigueLevels.put(uuid, newValue);
                }
            }
        }, interval, interval);
    }

    public void stopDecayTask() {
        if (decayTask != null) {
            decayTask.cancel();
        }
    }
}