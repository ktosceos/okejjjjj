package com.hardcorepvp.fatigue.listeners;

import com.hardcorepvp.fatigue.CombatFatigue;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.EntityDamageByEntityEvent;
import org.bukkit.event.entity.EntityDamageEvent;
import org.bukkit.event.entity.EntityRegainHealthEvent;

public class FatigueListener implements Listener {

    private final CombatFatigue plugin;

    public FatigueListener(CombatFatigue plugin) {
        this.plugin = plugin;
    }

    @EventHandler
    public void onDamage(EntityDamageByEntityEvent event) {
        if (!(event.getEntity() instanceof Player)) {
            return;
        }

        if (!(event.getDamager() instanceof Player)) {
            return;
        }

        Player attacker = (Player) event.getDamager();
        Player victim = (Player) event.getEntity();

        int fatiguePerHit = plugin.getConfig().getInt("fatigue-per-hit", 5);
        plugin.getFatigueManager().addFatigue(attacker.getUniqueId(), fatiguePerHit);

        double damageMultiplier = plugin.getFatigueManager().getDamageMultiplier(victim.getUniqueId());
        if (damageMultiplier > 1.0) {
            event.setDamage(event.getDamage() * damageMultiplier);
        }
    }

    @EventHandler
    public void onRegen(EntityRegainHealthEvent event) {
        if (!(event.getEntity() instanceof Player)) {
            return;
        }

        if (event.getRegainReason() != EntityRegainHealthEvent.RegainReason.SATIATED &&
            event.getRegainReason() != EntityRegainHealthEvent.RegainReason.REGEN) {
            return;
        }

        Player player = (Player) event.getEntity();
        double regenMultiplier = plugin.getFatigueManager().getRegenMultiplier(player.getUniqueId());

        if (regenMultiplier < 1.0) {
            event.setAmount(event.getAmount() * regenMultiplier);
        }
    }
}