package com.hardcorepvp.fatigue;

import com.hardcorepvp.fatigue.data.FatigueManager;
import com.hardcorepvp.fatigue.listeners.FatigueListener;
import lombok.Getter;
import org.bukkit.plugin.java.JavaPlugin;

public class CombatFatigue extends JavaPlugin {

    @Getter
    private static CombatFatigue instance;

    @Getter
    private FatigueManager fatigueManager;

    @Override
    public void onEnable() {
        instance = this;

        saveDefaultConfig();

        this.fatigueManager = new FatigueManager(this);

        getServer().getPluginManager().registerEvents(new FatigueListener(this), this);

        fatigueManager.startDecayTask();

        getLogger().info("CombatFatigue enabled!");
    }

    @Override
    public void onDisable() {
        if (fatigueManager != null) {
            fatigueManager.stopDecayTask();
        }
        getLogger().info("CombatFatigue disabled!");
    }
}