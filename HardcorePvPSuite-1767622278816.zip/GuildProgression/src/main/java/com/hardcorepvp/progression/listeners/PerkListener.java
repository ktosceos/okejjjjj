package com.hardcorepvp.progression.listeners;

import com.cryptomorin.xseries.XPotion;
import com.hardcorepvp.guilds.data.Guild;
import com.hardcorepvp.progression.GuildProgression;
import com.hardcorepvp.progression.data.GuildProgressionData;
import org.bukkit.Bukkit;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.player.PlayerJoinEvent;
import org.bukkit.potion.PotionEffect;

public class PerkListener implements Listener {

    private final GuildProgression plugin;

    public PerkListener(GuildProgression plugin) {
        this.plugin = plugin;

        Bukkit.getScheduler().runTaskTimer(plugin, this::applyPerks, 20L, 100L);
    }

    @EventHandler
    public void onJoin(PlayerJoinEvent event) {
        Bukkit.getScheduler().runTaskLater(plugin, () -> applyPerks(), 20L);
    }

    private void applyPerks() {
        for (Player player : Bukkit.getOnlinePlayers()) {
            Guild guild = plugin.getGuildsPlugin().getGuildManager().getPlayerGuild(player.getUniqueId());
            if (guild == null || guild.getBase() == null) {
                continue;
            }

            GuildProgressionData data = plugin.getProgressionManager().getProgression(guild.getName());

            int radius = plugin.getConfig().getInt("perks.radius", 50);
            double distance = player.getLocation().distance(guild.getBase());

            if (distance > radius) {
                continue;
            }

            if (plugin.getConfig().getBoolean("perks.regeneration.enabled")) {
                int minLevel = plugin.getConfig().getInt("perks.regeneration.min-guild-level");
                if (data.getLevel() >= minLevel) {
                    int level = plugin.getConfig().getInt("perks.regeneration.level", 1);
                    XPotion.matchXPotion("REGENERATION")
                        .map(xp -> xp.buildPotionEffect(200, level - 1))
                        .ifPresent(player::addPotionEffect);
                }
            }

            if (plugin.getConfig().getBoolean("perks.haste.enabled")) {
                int minLevel = plugin.getConfig().getInt("perks.haste.min-guild-level");
                if (data.getLevel() >= minLevel) {
                    int level = plugin.getConfig().getInt("perks.haste.level", 1);
                    XPotion.matchXPotion("FAST_DIGGING")
                        .map(xp -> xp.buildPotionEffect(200, level - 1))
                        .ifPresent(player::addPotionEffect);
                }
            }

            if (plugin.getConfig().getBoolean("perks.resistance.enabled")) {
                int minLevel = plugin.getConfig().getInt("perks.resistance.min-guild-level");
                if (data.getLevel() >= minLevel) {
                    int level = plugin.getConfig().getInt("perks.resistance.level", 1);
                    XPotion.matchXPotion("DAMAGE_RESISTANCE")
                        .map(xp -> xp.buildPotionEffect(200, level - 1))
                        .ifPresent(player::addPotionEffect);
                }
            }
        }
    }
}