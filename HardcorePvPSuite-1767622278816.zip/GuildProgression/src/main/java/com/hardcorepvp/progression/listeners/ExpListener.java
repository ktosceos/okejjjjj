package com.hardcorepvp.progression.listeners;

import com.hardcorepvp.guilds.data.Guild;
import com.hardcorepvp.progression.GuildProgression;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.PlayerDeathEvent;

public class ExpListener implements Listener {

    private final GuildProgression plugin;

    public ExpListener(GuildProgression plugin) {
        this.plugin = plugin;
    }

    @EventHandler
    public void onKill(PlayerDeathEvent event) {
        Player victim = event.getEntity();
        Player killer = victim.getKiller();

        if (killer == null) {
            return;
        }

        Guild killerGuild = plugin.getGuildsPlugin().getGuildManager().getPlayerGuild(killer.getUniqueId());
        if (killerGuild == null) {
            return;
        }

        int exp = plugin.getConfig().getInt("experience.pvp-kill", 50);
        plugin.getProgressionManager().addExperience(killerGuild.getName(), exp);
    }
}