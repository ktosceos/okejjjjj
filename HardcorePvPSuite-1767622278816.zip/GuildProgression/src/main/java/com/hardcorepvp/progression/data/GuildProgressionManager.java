package com.hardcorepvp.progression.data;

import com.hardcorepvp.guilds.data.Guild;
import com.hardcorepvp.progression.GuildProgression;
import org.bukkit.Bukkit;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.entity.Player;

import java.io.File;
import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

public class GuildProgressionManager {

    private final GuildProgression plugin;
    private final Map<String, GuildProgressionData> progressionData;

    public GuildProgressionManager(GuildProgression plugin) {
        this.plugin = plugin;
        this.progressionData = new HashMap<>();
    }

    public GuildProgressionData getProgression(String guildName) {
        return progressionData.computeIfAbsent(guildName.toLowerCase(), GuildProgressionData::new);
    }

    public void addExperience(String guildName, int amount) {
        GuildProgressionData data = getProgression(guildName);
        int oldLevel = data.getLevel();
        data.setExperience(data.getExperience() + amount);

        checkLevelUp(data);

        if (data.getLevel() > oldLevel) {
            notifyGuild(guildName, "level-up", data.getLevel());
        }

        int required = getRequiredExp(data.getLevel() + 1);
        notifyGuild(guildName, "exp-gain", amount, data.getExperience(), required);
    }

    private void checkLevelUp(GuildProgressionData data) {
        int nextLevel = data.getLevel() + 1;
        int required = getRequiredExp(nextLevel);

        if (required == -1) {
            return;
        }

        while (data.getExperience() >= required && required != -1) {
            data.setLevel(nextLevel);
            nextLevel++;
            required = getRequiredExp(nextLevel);
        }
    }

    public int getRequiredExp(int level) {
        ConfigurationSection levelsSection = plugin.getConfig().getConfigurationSection("levels");
        if (levelsSection == null || !levelsSection.contains(String.valueOf(level))) {
            return -1;
        }

        return levelsSection.getInt(level + ".required-exp", -1);
    }

    public int getMaxMembers(int level) {
        ConfigurationSection levelsSection = plugin.getConfig().getConfigurationSection("levels");
        if (levelsSection == null) {
            return 10;
        }

        for (int i = level; i >= 1; i--) {
            if (levelsSection.contains(String.valueOf(i))) {
                return levelsSection.getInt(i + ".max-members", 10);
            }
        }

        return 10;
    }

    public int getBaseCooldown(int level) {
        ConfigurationSection levelsSection = plugin.getConfig().getConfigurationSection("levels");
        if (levelsSection == null) {
            return 300;
        }

        for (int i = level; i >= 1; i--) {
            if (levelsSection.contains(String.valueOf(i))) {
                return levelsSection.getInt(i + ".base-cooldown", 300);
            }
        }

        return 300;
    }

    public int getTpaCooldown(int level) {
        ConfigurationSection levelsSection = plugin.getConfig().getConfigurationSection("levels");
        if (levelsSection == null) {
            return 60;
        }

        for (int i = level; i >= 1; i--) {
            if (levelsSection.contains(String.valueOf(i))) {
                return levelsSection.getInt(i + ".tpa-cooldown", 60);
            }
        }

        return 60;
    }

    public void grantOnlineExp() {
        int expPerHour = plugin.getConfig().getInt("experience.online-per-hour", 10);

        for (Guild guild : plugin.getGuildsPlugin().getGuildManager().getAllGuilds()) {
            int onlineMembers = 0;
            for (UUID memberId : guild.getMembers()) {
                if (Bukkit.getPlayer(memberId) != null) {
                    onlineMembers++;
                }
            }

            if (onlineMembers > 0) {
                addExperience(guild.getName(), expPerHour * onlineMembers);
            }
        }
    }

    private void notifyGuild(String guildName, String messageKey, Object... args) {
        Guild guild = plugin.getGuildsPlugin().getGuildManager().getGuild(guildName);
        if (guild == null) {
            return;
        }

        String message = plugin.getConfig().getString("messages." + messageKey, "");
        message = message.replace("&", "§");

        if (args.length >= 1) {
            if (messageKey.equals("level-up")) {
                message = message.replace("{level}", String.valueOf(args[0]));
            } else if (messageKey.equals("exp-gain")) {
                message = message.replace("{exp}", String.valueOf(args[0]));
                message = message.replace("{current}", String.valueOf(args[1]));
                message = message.replace("{required}", String.valueOf(args[2]));
            }
        }

        for (UUID memberId : guild.getMembers()) {
            Player member = Bukkit.getPlayer(memberId);
            if (member != null) {
                member.sendMessage(message);
            }
        }
    }

    public void load() {
        File file = new File(plugin.getDataFolder(), "progression.yml");
        if (!file.exists()) {
            return;
        }

        YamlConfiguration config = YamlConfiguration.loadConfiguration(file);
        ConfigurationSection guildsSection = config.getConfigurationSection("guilds");

        if (guildsSection == null) {
            return;
        }

        for (String guildName : guildsSection.getKeys(false)) {
            GuildProgressionData data = new GuildProgressionData(guildName);
            data.setLevel(guildsSection.getInt(guildName + ".level", 1));
            data.setExperience(guildsSection.getInt(guildName + ".experience", 0));
            progressionData.put(guildName.toLowerCase(), data);
        }

        plugin.getLogger().info("Loaded progression data for " + progressionData.size() + " guilds");
    }

    public void save() {
        File file = new File(plugin.getDataFolder(), "progression.yml");
        YamlConfiguration config = new YamlConfiguration();

        for (GuildProgressionData data : progressionData.values()) {
            String path = "guilds." + data.getGuildName();
            config.set(path + ".level", data.getLevel());
            config.set(path + ".experience", data.getExperience());
        }

        try {
            config.save(file);
            plugin.getLogger().info("Saved progression data for " + progressionData.size() + " guilds");
        } catch (Exception e) {
            plugin.getLogger().severe("Failed to save progression: " + e.getMessage());
        }
    }
}