package com.hardcorepvp.progression.commands;

import com.hardcorepvp.guilds.data.Guild;
import com.hardcorepvp.progression.GuildProgression;
import com.hardcorepvp.progression.data.GuildProgressionData;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;

public class ProgressionCommand implements CommandExecutor {

    private final GuildProgression plugin;

    public ProgressionCommand(GuildProgression plugin) {
        this.plugin = plugin;
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (!(sender instanceof Player)) {
            return true;
        }

        Player player = (Player) sender;

        if (args.length > 0 && args[0].equalsIgnoreCase("level")) {
            handleLevel(player);
            return true;
        }

        if (args.length > 0 && args[0].equalsIgnoreCase("perks")) {
            handlePerks(player);
            return true;
        }

        return false;
    }

    private void handleLevel(Player player) {
        Guild guild = plugin.getGuildsPlugin().getGuildManager().getPlayerGuild(player.getUniqueId());
        if (guild == null) {
            player.sendMessage("§cYou are not in a guild!");
            return;
        }

        GuildProgressionData data = plugin.getProgressionManager().getProgression(guild.getName());
        int nextRequired = plugin.getProgressionManager().getRequiredExp(data.getLevel() + 1);

        player.sendMessage("§6§l=== Guild Level ===");
        player.sendMessage("§7Level: §e" + data.getLevel());
        player.sendMessage("§7Experience: §e" + data.getExperience() +
                          (nextRequired != -1 ? "/" + nextRequired : " (MAX)"));
        player.sendMessage("§7Max Members: §e" + plugin.getProgressionManager().getMaxMembers(data.getLevel()));
        player.sendMessage("§7Base Cooldown: §e" + plugin.getProgressionManager().getBaseCooldown(data.getLevel()) + "s");
        player.sendMessage("§7TPA Cooldown: §e" + plugin.getProgressionManager().getTpaCooldown(data.getLevel()) + "s");
    }

    private void handlePerks(Player player) {
        Guild guild = plugin.getGuildsPlugin().getGuildManager().getPlayerGuild(player.getUniqueId());
        if (guild == null) {
            player.sendMessage("§cYou are not in a guild!");
            return;
        }

        GuildProgressionData data = plugin.getProgressionManager().getProgression(guild.getName());

        player.sendMessage("§6§l=== Guild Perks ===");

        if (plugin.getConfig().getBoolean("perks.regeneration.enabled")) {
            int minLevel = plugin.getConfig().getInt("perks.regeneration.min-guild-level");
            String status = data.getLevel() >= minLevel ? "§a✔" : "§c✘ (Level " + minLevel + ")";
            player.sendMessage(status + " §7Regeneration");
        }

        if (plugin.getConfig().getBoolean("perks.haste.enabled")) {
            int minLevel = plugin.getConfig().getInt("perks.haste.min-guild-level");
            String status = data.getLevel() >= minLevel ? "§a✔" : "§c✘ (Level " + minLevel + ")";
            player.sendMessage(status + " §7Haste");
        }

        if (plugin.getConfig().getBoolean("perks.resistance.enabled")) {
            int minLevel = plugin.getConfig().getInt("perks.resistance.min-guild-level");
            String status = data.getLevel() >= minLevel ? "§a✔" : "§c✘ (Level " + minLevel + ")";
            player.sendMessage(status + " §7Resistance");
        }

        if (plugin.getConfig().getBoolean("perks.combat-fatigue-immunity.enabled")) {
            int minLevel = plugin.getConfig().getInt("perks.combat-fatigue-immunity.min-guild-level");
            String status = data.getLevel() >= minLevel ? "§a✔" : "§c✘ (Level " + minLevel + ")";
            player.sendMessage(status + " §7Combat Fatigue Immunity");
        }
    }
}