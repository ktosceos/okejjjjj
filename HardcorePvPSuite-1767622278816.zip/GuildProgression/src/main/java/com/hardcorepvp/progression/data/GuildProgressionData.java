package com.hardcorepvp.progression.data;

import lombok.Data;

@Data
public class GuildProgressionData {
    private String guildName;
    private int level;
    private int experience;

    public GuildProgressionData(String guildName) {
        this.guildName = guildName;
        this.level = 1;
        this.experience = 0;
    }
}