package com.hardcorepvp.progression;

import com.hardcorepvp.guilds.HardcoreGuilds;
import com.hardcorepvp.progression.commands.ProgressionCommand;
import com.hardcorepvp.progression.data.GuildProgressionManager;
import com.hardcorepvp.progression.listeners.ExpListener;
import com.hardcorepvp.progression.listeners.PerkListener;
import lombok.Getter;
import org.bukkit.plugin.java.JavaPlugin;

public class GuildProgression extends JavaPlugin {

    @Getter
    private static GuildProgression instance;

    @Getter
    private GuildProgressionManager progressionManager;

    @Getter
    private HardcoreGuilds guildsPlugin;

    @Override
    public void onEnable() {
        instance = this;

        guildsPlugin = (HardcoreGuilds) getServer().getPluginManager().getPlugin("HardcoreGuilds");
        if (guildsPlugin == null) {
            getLogger().severe("HardcoreGuilds not found! Disabling plugin.");
            getServer().getPluginManager().disablePlugin(this);
            return;
        }

        saveDefaultConfig();

        this.progressionManager = new GuildProgressionManager(this);
        this.progressionManager.load();

        getCommand("g").setExecutor(new ProgressionCommand(this));

        getServer().getPluginManager().registerEvents(new ExpListener(this), this);
        getServer().getPluginManager().registerEvents(new PerkListener(this), this);

        getServer().getScheduler().runTaskTimer(this, () -> {
            progressionManager.grantOnlineExp();
        }, 72000L, 72000L);

        getLogger().info("GuildProgression enabled!");
    }

    @Override
    public void onDisable() {
        if (progressionManager != null) {
            progressionManager.save();
        }
        getLogger().info("GuildProgression disabled!");
    }
}