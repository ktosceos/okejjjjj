package com.hardcorepvp.guilds.gui;

import com.hardcorepvp.guilds.HardcoreGuilds;
import com.hardcorepvp.guilds.data.Guild;
import org.bukkit.Bukkit;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.inventory.InventoryCloseEvent;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.ItemStack;

import java.util.HashMap;
import java.util.Map;

public class GuildChestGUI implements Listener {

    private final HardcoreGuilds plugin;
    private final Guild guild;
    private final Inventory inventory;

    public GuildChestGUI(HardcoreGuilds plugin, Guild guild) {
        this.plugin = plugin;
        this.guild = guild;
        this.inventory = Bukkit.createInventory(null, 54, "§6Guild Chest - " + guild.getName());

        for (Map.Entry<Integer, ItemStack> entry : guild.getChest().entrySet()) {
            if (entry.getKey() >= 0 && entry.getKey() < 54 && entry.getValue() != null) {
                inventory.setItem(entry.getKey(), entry.getValue());
            }
        }

        Bukkit.getPluginManager().registerEvents(this, plugin);
    }

    public void open(Player player) {
        player.openInventory(inventory);
    }

    @EventHandler
    public void onClose(InventoryCloseEvent event) {
        if (!event.getInventory().equals(inventory)) {
            return;
        }

        Map<Integer, ItemStack> newChest = new HashMap<>();
        for (int i = 0; i < inventory.getSize(); i++) {
            ItemStack item = inventory.getItem(i);
            if (item != null) {
                newChest.put(i, item);
            }
        }

        guild.setChest(newChest);
    }
}