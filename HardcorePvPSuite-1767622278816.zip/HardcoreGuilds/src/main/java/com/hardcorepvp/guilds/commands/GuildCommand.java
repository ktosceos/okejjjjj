package com.hardcorepvp.guilds.commands;

import com.hardcorepvp.core.HardcorePvPCore;
import com.hardcorepvp.guilds.HardcoreGuilds;
import com.hardcorepvp.guilds.data.Guild;
import com.hardcorepvp.guilds.gui.GuildChestGUI;
import org.bukkit.Bukkit;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;

public class GuildCommand implements CommandExecutor {

    private final HardcoreGuilds plugin;

    public GuildCommand(HardcoreGuilds plugin) {
        this.plugin = plugin;
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (!(sender instanceof Player)) {
            sender.sendMessage("§cOnly players can use this command!");
            return true;
        }

        Player player = (Player) sender;

        if (!player.hasPermission("guild.use")) {
            player.sendMessage(msg("no-permission"));
            return true;
        }

        if (args.length == 0) {
            sendHelp(player);
            return true;
        }

        switch (args[0].toLowerCase()) {
            case "create":
                handleCreate(player, args);
                break;
            case "invite":
                handleInvite(player, args);
                break;
            case "join":
                handleJoin(player, args);
                break;
            case "kick":
                handleKick(player, args);
                break;
            case "leave":
                handleLeave(player);
                break;
            case "disband":
                handleDisband(player);
                break;
            case "info":
                handleInfo(player);
                break;
            case "members":
                handleMembers(player);
                break;
            case "chest":
                handleChest(player);
                break;
            case "base":
                handleBase(player);
                break;
            case "tpa":
                handleTpa(player, args);
                break;
            default:
                sendHelp(player);
        }

        return true;
    }

    private void handleCreate(Player player, String[] args) {
        if (args.length < 2) {
            player.sendMessage("§cUsage: /g create <name>");
            return;
        }

        if (plugin.getGuildManager().hasGuild(player.getUniqueId())) {
            player.sendMessage(msg("already-in-guild"));
            return;
        }

        String name = args[1];
        int minLength = plugin.getConfig().getInt("guild.min-name-length", 3);
        int maxLength = plugin.getConfig().getInt("guild.max-name-length", 16);

        if (name.length() < minLength || name.length() > maxLength) {
            player.sendMessage("§cGuild name must be between " + minLength + " and " + maxLength + " characters!");
            return;
        }

        if (plugin.getGuildManager().guildExists(name)) {
            player.sendMessage(msg("guild-exists"));
            return;
        }

        double cost = plugin.getConfig().getDouble("guild.creation-cost", 1000.0);
        if (plugin.getEconomy().getBalance(player) < cost) {
            player.sendMessage(msg("insufficient-funds").replace("{cost}", String.valueOf(cost)));
            return;
        }

        plugin.getEconomy().withdrawPlayer(player, cost);
        plugin.getGuildManager().createGuild(name, player.getUniqueId());

        player.sendMessage(msg("created").replace("{guild}", name));
    }

    private void handleInvite(Player player, String[] args) {
        if (args.length < 2) {
            player.sendMessage("§cUsage: /g invite <player>");
            return;
        }

        Guild guild = plugin.getGuildManager().getPlayerGuild(player.getUniqueId());
        if (guild == null) {
            player.sendMessage(msg("no-guild"));
            return;
        }

        if (!guild.isLeader(player.getUniqueId())) {
            player.sendMessage(msg("no-permission"));
            return;
        }

        Player target = Bukkit.getPlayer(args[1]);
        if (target == null) {
            player.sendMessage("§cPlayer not found!");
            return;
        }

        if (plugin.getGuildManager().hasGuild(target.getUniqueId())) {
            player.sendMessage("§cThat player is already in a guild!");
            return;
        }

        int maxMembers = plugin.getConfig().getInt("guild.max-members", 10);
        if (guild.getMembers().size() >= maxMembers) {
            player.sendMessage("§cYour guild is full!");
            return;
        }

        target.sendMessage(msg("invited").replace("{guild}", guild.getName()));
        player.sendMessage("§aYou have invited §e" + target.getName() + " §ato the guild!");
    }

    private void handleJoin(Player player, String[] args) {
        if (args.length < 2) {
            player.sendMessage("§cUsage: /g join <guild>");
            return;
        }

        if (plugin.getGuildManager().hasGuild(player.getUniqueId())) {
            player.sendMessage(msg("already-in-guild"));
            return;
        }

        Guild guild = plugin.getGuildManager().getGuild(args[1]);
        if (guild == null) {
            player.sendMessage(msg("not-found"));
            return;
        }

        int maxMembers = plugin.getConfig().getInt("guild.max-members", 10);
        if (guild.getMembers().size() >= maxMembers) {
            player.sendMessage("§cThat guild is full!");
            return;
        }

        plugin.getGuildManager().joinGuild(player.getUniqueId(), guild);

        player.sendMessage(msg("joined").replace("{player}", player.getName()));

        for (java.util.UUID memberId : guild.getMembers()) {
            Player member = Bukkit.getPlayer(memberId);
            if (member != null && !member.equals(player)) {
                member.sendMessage(msg("joined").replace("{player}", player.getName()));
            }
        }
    }

    private void handleKick(Player player, String[] args) {
        if (args.length < 2) {
            player.sendMessage("§cUsage: /g kick <player>");
            return;
        }

        Guild guild = plugin.getGuildManager().getPlayerGuild(player.getUniqueId());
        if (guild == null) {
            player.sendMessage(msg("no-guild"));
            return;
        }

        if (!guild.isLeader(player.getUniqueId())) {
            player.sendMessage(msg("no-permission"));
            return;
        }

        Player target = Bukkit.getPlayer(args[1]);
        if (target == null) {
            player.sendMessage("§cPlayer not found!");
            return;
        }

        if (!guild.isMember(target.getUniqueId())) {
            player.sendMessage("§cThat player is not in your guild!");
            return;
        }

        if (guild.isLeader(target.getUniqueId())) {
            player.sendMessage("§cYou cannot kick yourself!");
            return;
        }

        plugin.getGuildManager().leaveGuild(target.getUniqueId());

        target.sendMessage(msg("kicked").replace("{player}", target.getName()));
        player.sendMessage("§aYou have kicked §e" + target.getName() + " §afrom the guild!");
    }

    private void handleLeave(Player player) {
        Guild guild = plugin.getGuildManager().getPlayerGuild(player.getUniqueId());
        if (guild == null) {
            player.sendMessage(msg("no-guild"));
            return;
        }

        if (guild.isLeader(player.getUniqueId())) {
            player.sendMessage("§cYou must disband the guild or transfer leadership first!");
            return;
        }

        plugin.getGuildManager().leaveGuild(player.getUniqueId());

        player.sendMessage(msg("left").replace("{player}", player.getName()));

        for (java.util.UUID memberId : guild.getMembers()) {
            Player member = Bukkit.getPlayer(memberId);
            if (member != null) {
                member.sendMessage(msg("left").replace("{player}", player.getName()));
            }
        }
    }

    private void handleDisband(Player player) {
        Guild guild = plugin.getGuildManager().getPlayerGuild(player.getUniqueId());
        if (guild == null) {
            player.sendMessage(msg("no-guild"));
            return;
        }

        if (!guild.isLeader(player.getUniqueId())) {
            player.sendMessage(msg("no-permission"));
            return;
        }

        String guildName = guild.getName();

        for (java.util.UUID memberId : new java.util.HashSet<>(guild.getMembers())) {
            Player member = Bukkit.getPlayer(memberId);
            if (member != null) {
                member.sendMessage(msg("disbanded").replace("{guild}", guildName));
            }
        }

        plugin.getGuildManager().disbandGuild(guildName);
    }

    private void handleInfo(Player player) {
        Guild guild = plugin.getGuildManager().getPlayerGuild(player.getUniqueId());
        if (guild == null) {
            player.sendMessage(msg("no-guild"));
            return;
        }

        player.sendMessage("§6§l=== " + guild.getName() + " ===");
        player.sendMessage("§7Leader: §e" + Bukkit.getOfflinePlayer(guild.getLeader()).getName());
        player.sendMessage("§7Members: §e" + guild.getMembers().size() + "/" + plugin.getConfig().getInt("guild.max-members", 10));
        player.sendMessage("§7Created: §e" + new java.text.SimpleDateFormat("yyyy-MM-dd").format(new java.util.Date(guild.getCreated())));
    }

    private void handleMembers(Player player) {
        Guild guild = plugin.getGuildManager().getPlayerGuild(player.getUniqueId());
        if (guild == null) {
            player.sendMessage(msg("no-guild"));
            return;
        }

        player.sendMessage("§6§l=== Members of " + guild.getName() + " ===");
        for (java.util.UUID memberId : guild.getMembers()) {
            String memberName = Bukkit.getOfflinePlayer(memberId).getName();
            String role = guild.isLeader(memberId) ? " §7(Leader)" : "";
            String status = Bukkit.getPlayer(memberId) != null ? "§a● " : "§7● ";
            player.sendMessage(status + "§e" + memberName + role);
        }
    }

    private void handleChest(Player player) {
        Guild guild = plugin.getGuildManager().getPlayerGuild(player.getUniqueId());
        if (guild == null) {
            player.sendMessage(msg("no-guild"));
            return;
        }

        new GuildChestGUI(plugin, guild).open(player);
    }

    private void handleBase(Player player) {
        Guild guild = plugin.getGuildManager().getPlayerGuild(player.getUniqueId());
        if (guild == null) {
            player.sendMessage(msg("no-guild"));
            return;
        }

        HardcorePvPCore corePlugin = (HardcorePvPCore) Bukkit.getPluginManager().getPlugin("HardcorePvPCore");
        if (corePlugin != null && corePlugin.getCombatManager().isInCombat(player)) {
            player.sendMessage(msg("combat-active"));
            return;
        }

        if (plugin.getGuildManager().hasCooldown(player.getUniqueId(), "base")) {
            long remaining = plugin.getGuildManager().getCooldownRemaining(player.getUniqueId(), "base");
            player.sendMessage(msg("cooldown").replace("{time}", String.valueOf(remaining)));
            return;
        }

        if (guild.getBase() == null) {
            guild.setBase(player.getLocation());
            player.sendMessage("§aGuild base set to your current location!");
            return;
        }

        double cost = plugin.getConfig().getDouble("teleport.base-cost", 100.0);
        if (plugin.getEconomy().getBalance(player) < cost) {
            player.sendMessage(msg("insufficient-funds").replace("{cost}", String.valueOf(cost)));
            return;
        }

        plugin.getEconomy().withdrawPlayer(player, cost);
        player.teleport(guild.getBase());
        player.sendMessage("§aTeleported to guild base!");

        int cooldown = plugin.getConfig().getInt("teleport.base-cooldown", 300);
        plugin.getGuildManager().setCooldown(player.getUniqueId(), "base", cooldown);
    }

    private void handleTpa(Player player, String[] args) {
        if (args.length < 2) {
            player.sendMessage("§cUsage: /g tpa <player>");
            return;
        }

        Guild guild = plugin.getGuildManager().getPlayerGuild(player.getUniqueId());
        if (guild == null) {
            player.sendMessage(msg("no-guild"));
            return;
        }

        Player target = Bukkit.getPlayer(args[1]);
        if (target == null) {
            player.sendMessage("§cPlayer not found!");
            return;
        }

        if (!guild.isMember(target.getUniqueId())) {
            player.sendMessage("§cThat player is not in your guild!");
            return;
        }

        HardcorePvPCore corePlugin = (HardcorePvPCore) Bukkit.getPluginManager().getPlugin("HardcorePvPCore");
        if (corePlugin != null && corePlugin.getCombatManager().isInCombat(player)) {
            player.sendMessage(msg("combat-active"));
            return;
        }

        if (plugin.getGuildManager().hasCooldown(player.getUniqueId(), "tpa")) {
            long remaining = plugin.getGuildManager().getCooldownRemaining(player.getUniqueId(), "tpa");
            player.sendMessage(msg("cooldown").replace("{time}", String.valueOf(remaining)));
            return;
        }

        double cost = plugin.getConfig().getDouble("teleport.tpa-cost", 50.0);
        if (plugin.getEconomy().getBalance(player) < cost) {
            player.sendMessage(msg("insufficient-funds").replace("{cost}", String.valueOf(cost)));
            return;
        }

        plugin.getEconomy().withdrawPlayer(player, cost);
        player.teleport(target.getLocation());
        player.sendMessage("§aTeleported to §e" + target.getName() + "§a!");
        target.sendMessage("§e" + player.getName() + " §ateleported to you!");

        int cooldown = plugin.getConfig().getInt("teleport.tpa-cooldown", 60);
        plugin.getGuildManager().setCooldown(player.getUniqueId(), "tpa", cooldown);
    }

    private void sendHelp(Player player) {
        player.sendMessage("§6§l=== Guild Commands ===");
        player.sendMessage("§e/g create <name> §7- Create a guild");
        player.sendMessage("§e/g invite <player> §7- Invite a player");
        player.sendMessage("§e/g join <guild> §7- Join a guild");
        player.sendMessage("§e/g kick <player> §7- Kick a member");
        player.sendMessage("§e/g leave §7- Leave your guild");
        player.sendMessage("§e/g disband §7- Disband your guild");
        player.sendMessage("§e/g info §7- Guild information");
        player.sendMessage("§e/g members §7- List members");
        player.sendMessage("§e/g chest §7- Open guild chest");
        player.sendMessage("§e/g base §7- Set or teleport to base");
        player.sendMessage("§e/g tpa <player> §7- Teleport to guild member");
    }

    private String msg(String key) {
        return plugin.getConfig().getString("messages." + key, "&c" + key).replace("&", "§");
    }
}