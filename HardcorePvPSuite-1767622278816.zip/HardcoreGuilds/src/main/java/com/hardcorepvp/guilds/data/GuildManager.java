package com.hardcorepvp.guilds.data;

import com.hardcorepvp.guilds.HardcoreGuilds;
import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.inventory.ItemStack;

import java.io.File;
import java.util.*;

public class GuildManager {

    private final HardcoreGuilds plugin;
    private final Map<String, Guild> guilds;
    private final Map<UUID, String> playerGuilds;
    private final Map<UUID, Map<String, Long>> cooldowns;

    public GuildManager(HardcoreGuilds plugin) {
        this.plugin = plugin;
        this.guilds = new HashMap<>();
        this.playerGuilds = new HashMap<>();
        this.cooldowns = new HashMap<>();
    }

    public Guild createGuild(String name, UUID leader) {
        Guild guild = new Guild(name, leader);
        guilds.put(name.toLowerCase(), guild);
        playerGuilds.put(leader, name.toLowerCase());
        return guild;
    }

    public void disbandGuild(String name) {
        Guild guild = guilds.remove(name.toLowerCase());
        if (guild != null) {
            for (UUID member : guild.getMembers()) {
                playerGuilds.remove(member);
            }
        }
    }

    public Guild getGuild(String name) {
        return guilds.get(name.toLowerCase());
    }

    public Guild getPlayerGuild(UUID uuid) {
        String guildName = playerGuilds.get(uuid);
        return guildName != null ? guilds.get(guildName) : null;
    }

    public boolean hasGuild(UUID uuid) {
        return playerGuilds.containsKey(uuid);
    }

    public boolean guildExists(String name) {
        return guilds.containsKey(name.toLowerCase());
    }

    public void joinGuild(UUID uuid, Guild guild) {
        playerGuilds.put(uuid, guild.getName().toLowerCase());
        guild.addMember(uuid);
    }

    public void leaveGuild(UUID uuid) {
        Guild guild = getPlayerGuild(uuid);
        if (guild != null) {
            guild.removeMember(uuid);
            playerGuilds.remove(uuid);

            if (guild.getMembers().isEmpty()) {
                guilds.remove(guild.getName().toLowerCase());
            }
        }
    }

    public boolean hasCooldown(UUID uuid, String type) {
        if (!cooldowns.containsKey(uuid)) {
            return false;
        }

        Map<String, Long> playerCooldowns = cooldowns.get(uuid);
        if (!playerCooldowns.containsKey(type)) {
            return false;
        }

        return System.currentTimeMillis() < playerCooldowns.get(type);
    }

    public long getCooldownRemaining(UUID uuid, String type) {
        if (!hasCooldown(uuid, type)) {
            return 0;
        }

        long endTime = cooldowns.get(uuid).get(type);
        return (endTime - System.currentTimeMillis()) / 1000;
    }

    public void setCooldown(UUID uuid, String type, int seconds) {
        cooldowns.putIfAbsent(uuid, new HashMap<>());
        cooldowns.get(uuid).put(type, System.currentTimeMillis() + (seconds * 1000L));
    }

    public void loadGuilds() {
        File file = new File(plugin.getDataFolder(), "guilds.yml");
        if (!file.exists()) {
            return;
        }

        YamlConfiguration config = YamlConfiguration.loadConfiguration(file);
        ConfigurationSection guildsSection = config.getConfigurationSection("guilds");

        if (guildsSection == null) {
            return;
        }

        for (String guildName : guildsSection.getKeys(false)) {
            ConfigurationSection guildSection = guildsSection.getConfigurationSection(guildName);

            UUID leader = UUID.fromString(guildSection.getString("leader"));
            Guild guild = new Guild(guildName, leader);

            List<String> memberStrings = guildSection.getStringList("members");
            for (String memberStr : memberStrings) {
                UUID memberId = UUID.fromString(memberStr);
                guild.addMember(memberId);
                playerGuilds.put(memberId, guildName.toLowerCase());
            }

            if (guildSection.contains("base")) {
                guild.setBase((Location) guildSection.get("base"));
            }

            if (guildSection.contains("chest")) {
                ConfigurationSection chestSection = guildSection.getConfigurationSection("chest");
                for (String slot : chestSection.getKeys(false)) {
                    ItemStack item = chestSection.getItemStack(slot);
                    guild.getChest().put(Integer.parseInt(slot), item);
                }
            }

            guild.setCreated(guildSection.getLong("created", System.currentTimeMillis()));

            guilds.put(guildName.toLowerCase(), guild);
        }

        plugin.getLogger().info("Loaded " + guilds.size() + " guilds");
    }

    public void saveGuilds() {
        File file = new File(plugin.getDataFolder(), "guilds.yml");
        YamlConfiguration config = new YamlConfiguration();

        for (Guild guild : guilds.values()) {
            String path = "guilds." + guild.getName();

            config.set(path + ".leader", guild.getLeader().toString());

            List<String> memberStrings = new ArrayList<>();
            for (UUID member : guild.getMembers()) {
                memberStrings.add(member.toString());
            }
            config.set(path + ".members", memberStrings);

            if (guild.getBase() != null) {
                config.set(path + ".base", guild.getBase());
            }

            if (!guild.getChest().isEmpty()) {
                for (Map.Entry<Integer, ItemStack> entry : guild.getChest().entrySet()) {
                    config.set(path + ".chest." + entry.getKey(), entry.getValue());
                }
            }

            config.set(path + ".created", guild.getCreated());
        }

        try {
            config.save(file);
            plugin.getLogger().info("Saved " + guilds.size() + " guilds");
        } catch (Exception e) {
            plugin.getLogger().severe("Failed to save guilds: " + e.getMessage());
        }
    }

    public Collection<Guild> getAllGuilds() {
        return guilds.values();
    }
}