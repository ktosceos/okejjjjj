package com.hardcorepvp.guilds.data;

import lombok.Data;
import org.bukkit.Location;

import java.util.*;

@Data
public class Guild {
    private String name;
    private UUID leader;
    private Set<UUID> members;
    private Location base;
    private Map<Integer, org.bukkit.inventory.ItemStack> chest;
    private long created;

    public Guild(String name, UUID leader) {
        this.name = name;
        this.leader = leader;
        this.members = new HashSet<>();
        this.members.add(leader);
        this.chest = new HashMap<>();
        this.created = System.currentTimeMillis();
    }

    public boolean isMember(UUID uuid) {
        return members.contains(uuid);
    }

    public boolean isLeader(UUID uuid) {
        return leader.equals(uuid);
    }

    public void addMember(UUID uuid) {
        members.add(uuid);
    }

    public void removeMember(UUID uuid) {
        members.remove(uuid);
    }
}