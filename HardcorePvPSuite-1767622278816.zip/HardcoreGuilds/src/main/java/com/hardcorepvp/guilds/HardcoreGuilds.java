package com.hardcorepvp.guilds;

import com.hardcorepvp.guilds.commands.GuildCommand;
import com.hardcorepvp.guilds.data.GuildManager;
import lombok.Getter;
import net.milkbowl.vault.economy.Economy;
import org.bukkit.plugin.RegisteredServiceProvider;
import org.bukkit.plugin.java.JavaPlugin;

public class HardcoreGuilds extends JavaPlugin {

    @Getter
    private static HardcoreGuilds instance;

    @Getter
    private GuildManager guildManager;

    @Getter
    private Economy economy;

    @Override
    public void onEnable() {
        instance = this;

        if (!setupEconomy()) {
            getLogger().severe("Vault not found! Disabling plugin.");
            getServer().getPluginManager().disablePlugin(this);
            return;
        }

        saveDefaultConfig();

        this.guildManager = new GuildManager(this);
        this.guildManager.loadGuilds();

        getCommand("g").setExecutor(new GuildCommand(this));

        getLogger().info("HardcoreGuilds enabled!");
    }

    @Override
    public void onDisable() {
        if (guildManager != null) {
            guildManager.saveGuilds();
        }
        getLogger().info("HardcoreGuilds disabled!");
    }

    private boolean setupEconomy() {
        if (getServer().getPluginManager().getPlugin("Vault") == null) {
            return false;
        }

        RegisteredServiceProvider<Economy> rsp = getServer().getServicesManager().getRegistration(Economy.class);
        if (rsp == null) {
            return false;
        }

        economy = rsp.getProvider();
        return economy != null;
    }
}