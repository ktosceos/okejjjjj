package com.hardcorepvp.tension.data;

import com.hardcorepvp.tension.WorldTension;
import org.bukkit.Bukkit;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.scheduler.BukkitTask;

import java.io.File;

public class TensionManager {

    private final WorldTension plugin;
    private int globalTension;
    private BukkitTask decayTask;

    public TensionManager(WorldTension plugin) {
        this.plugin = plugin;
        this.globalTension = 0;
    }

    public int getTension() {
        return globalTension;
    }

    public void setTension(int value) {
        globalTension = Math.max(0, Math.min(100, value));

        if (globalTension >= 75) {
            Bukkit.broadcastMessage("§c§lWORLD TENSION: CRITICAL!");
        } else if (globalTension >= 50) {
            Bukkit.broadcastMessage("§6§lWORLD TENSION: HIGH");
        }
    }

    public void addTension(int amount) {
        setTension(globalTension + amount);
    }

    public void onWarDeclared() {
        addTension(plugin.getConfig().getInt("tension-gain.war-declared", 10));
    }

    public void onPvPKill() {
        addTension(plugin.getConfig().getInt("tension-gain.pvp-kill", 1));
    }

    public void onBaseDestroyed() {
        addTension(plugin.getConfig().getInt("tension-gain.base-destroyed", 20));
    }

    public double getAirdropMultiplier() {
        if (globalTension >= 75) return 2.0;
        if (globalTension >= 50) return 1.5;
        return 1.0;
    }

    public double getEventSeverityMultiplier() {
        return 1.0 + (globalTension / 100.0);
    }

    public void startDecayTask() {
        decayTask = Bukkit.getScheduler().runTaskTimer(plugin, () -> {
            if (globalTension > 0) {
                addTension(-1);
            }
        }, 12000L, 12000L);
    }

    public void stopDecayTask() {
        if (decayTask != null) {
            decayTask.cancel();
        }
    }

    public void load() {
        File file = new File(plugin.getDataFolder(), "tension.yml");
        if (!file.exists()) return;

        YamlConfiguration config = YamlConfiguration.loadConfiguration(file);
        globalTension = config.getInt("tension", 0);
    }

    public void save() {
        File file = new File(plugin.getDataFolder(), "tension.yml");
        YamlConfiguration config = new YamlConfiguration();

        config.set("tension", globalTension);

        try {
            config.save(file);
        } catch (Exception e) {
            plugin.getLogger().severe("Failed to save tension: " + e.getMessage());
        }
    }
}