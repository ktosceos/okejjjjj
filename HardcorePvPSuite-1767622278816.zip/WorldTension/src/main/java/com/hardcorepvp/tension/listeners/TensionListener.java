package com.hardcorepvp.tension.listeners;

import com.hardcorepvp.tension.WorldTension;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.PlayerDeathEvent;

public class TensionListener implements Listener {

    private final WorldTension plugin;

    public TensionListener(WorldTension plugin) {
        this.plugin = plugin;
    }

    @EventHandler
    public void onDeath(PlayerDeathEvent event) {
        if (event.getEntity().getKiller() != null) {
            plugin.getTensionManager().onPvPKill();
        }
    }
}