package com.hardcorepvp.tension;

import com.hardcorepvp.tension.commands.TensionCommand;
import com.hardcorepvp.tension.data.TensionManager;
import com.hardcorepvp.tension.listeners.TensionListener;
import lombok.Getter;
import org.bukkit.plugin.java.JavaPlugin;

public class WorldTension extends JavaPlugin {

    @Getter
    private static WorldTension instance;

    @Getter
    private TensionManager tensionManager;

    @Override
    public void onEnable() {
        instance = this;

        saveDefaultConfig();

        this.tensionManager = new TensionManager(this);
        this.tensionManager.load();

        getCommand("tension").setExecutor(new TensionCommand(this));

        getServer().getPluginManager().registerEvents(new TensionListener(this), this);

        tensionManager.startDecayTask();

        getLogger().info("WorldTension enabled!");
    }

    @Override
    public void onDisable() {
        if (tensionManager != null) {
            tensionManager.stopDecayTask();
            tensionManager.save();
        }
        getLogger().info("WorldTension disabled!");
    }
}