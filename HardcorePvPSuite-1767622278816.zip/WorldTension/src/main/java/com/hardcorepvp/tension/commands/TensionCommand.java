package com.hardcorepvp.tension.commands;

import com.hardcorepvp.tension.WorldTension;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;

public class TensionCommand implements CommandExecutor {

    private final WorldTension plugin;

    public TensionCommand(WorldTension plugin) {
        this.plugin = plugin;
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        int tension = plugin.getTensionManager().getTension();

        String bar = getBar(tension);
        String status = getStatus(tension);

        sender.sendMessage("§c§l=== WORLD TENSION ===");
        sender.sendMessage("§7Level: " + bar + " §e" + tension + "/100");
        sender.sendMessage("§7Status: " + status);

        return true;
    }

    private String getBar(int tension) {
        int filled = tension / 10;
        StringBuilder bar = new StringBuilder("§c");

        for (int i = 0; i < 10; i++) {
            if (i < filled) {
                bar.append("█");
            } else {
                bar.append("§7█");
            }
        }

        return bar.toString();
    }

    private String getStatus(int tension) {
        if (tension >= 75) return "§c§lCRITICAL";
        if (tension >= 50) return "§6§lHIGH";
        if (tension >= 25) return "§e§lMODERATE";
        return "§a§lPEACEFUL";
    }
}