package com.hardcorepvp.morale.data;

import com.hardcorepvp.morale.PlayerMorale;
import org.bukkit.Bukkit;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.entity.Player;
import org.bukkit.scheduler.BukkitTask;

import java.io.File;
import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

public class MoraleManager {

    private final PlayerMorale plugin;
    private final Map<UUID, Integer> morale;
    private final Map<UUID, Long> lastDeath;
    private final Map<UUID, Integer> deathStreak;
    private BukkitTask decayTask;

    public MoraleManager(PlayerMorale plugin) {
        this.plugin = plugin;
        this.morale = new HashMap<>();
        this.lastDeath = new HashMap<>();
        this.deathStreak = new HashMap<>();
    }

    public int getMorale(UUID uuid) {
        return morale.getOrDefault(uuid, 50);
    }

    public void setMorale(UUID uuid, int value) {
        morale.put(uuid, Math.max(0, Math.min(100, value)));
    }

    public void addMorale(UUID uuid, int amount) {
        setMorale(uuid, getMorale(uuid) + amount);
    }

    public void onDeath(UUID uuid) {
        int current = getMorale(uuid);
        int penalty = plugin.getConfig().getInt("morale-loss.death", 10);

        long now = System.currentTimeMillis();
        Long last = lastDeath.get(uuid);

        if (last != null && (now - last) < 60000) {
            int streak = deathStreak.getOrDefault(uuid, 0) + 1;
            deathStreak.put(uuid, streak);
            penalty += streak * 5;
        } else {
            deathStreak.put(uuid, 0);
        }

        lastDeath.put(uuid, now);
        addMorale(uuid, -penalty);

        Player player = Bukkit.getPlayer(uuid);
        if (player != null && current >= 50 && getMorale(uuid) < 50) {
            player.sendMessage("§c§lYour morale is breaking down!");
        }
    }

    public void onFlee(UUID uuid) {
        addMorale(uuid, -plugin.getConfig().getInt("morale-loss.flee", 15));
    }

    public void onBountyTarget(UUID uuid) {
        addMorale(uuid, -plugin.getConfig().getInt("morale-loss.bounty-target", 20));
    }

    public void onGuildBetrayal(UUID uuid) {
        addMorale(uuid, -plugin.getConfig().getInt("morale-loss.guild-betrayal", 50));
    }

    public void onPvPWin(UUID uuid) {
        addMorale(uuid, plugin.getConfig().getInt("morale-gain.pvp-win", 15));
    }

    public void onBaseDefense(UUID uuid) {
        addMorale(uuid, plugin.getConfig().getInt("morale-gain.base-defense", 20));
    }

    public void onBountyKill(UUID uuid) {
        addMorale(uuid, plugin.getConfig().getInt("morale-gain.bounty-kill", 25));
    }

    public double getAttackDelayMultiplier(UUID uuid) {
        int m = getMorale(uuid);
        if (m < 25) return 1.5;
        if (m < 50) return 1.2;
        return 1.0;
    }

    public double getCritChanceBonus(UUID uuid) {
        int m = getMorale(uuid);
        if (m >= 75) return plugin.getConfig().getDouble("effects.high-morale.crit-bonus", 0.15);
        return 0.0;
    }

    public boolean shouldPanicBreak(UUID uuid) {
        int m = getMorale(uuid);
        if (m >= 25) return false;

        double chance = plugin.getConfig().getDouble("effects.low-morale.panic-chance", 0.1);
        return Math.random() < chance;
    }

    public void startDecayTask() {
        decayTask = Bukkit.getScheduler().runTaskTimer(plugin, () -> {
            for (UUID uuid : new HashMap<>(morale).keySet()) {
                Player player = Bukkit.getPlayer(uuid);
                if (player == null) continue;

                int current = getMorale(uuid);
                if (current < 50) {
                    addMorale(uuid, 1);
                } else if (current > 50) {
                    addMorale(uuid, -1);
                }
            }
        }, 6000L, 6000L);
    }

    public void stopDecayTask() {
        if (decayTask != null) {
            decayTask.cancel();
        }
    }

    public void load() {
        File file = new File(plugin.getDataFolder(), "morale.yml");
        if (!file.exists()) return;

        YamlConfiguration config = YamlConfiguration.loadConfiguration(file);
        for (String key : config.getKeys(false)) {
            morale.put(UUID.fromString(key), config.getInt(key));
        }
    }

    public void save() {
        File file = new File(plugin.getDataFolder(), "morale.yml");
        YamlConfiguration config = new YamlConfiguration();

        for (Map.Entry<UUID, Integer> entry : morale.entrySet()) {
            config.set(entry.getKey().toString(), entry.getValue());
        }

        try {
            config.save(file);
        } catch (Exception e) {
            plugin.getLogger().severe("Failed to save morale: " + e.getMessage());
        }
    }
}