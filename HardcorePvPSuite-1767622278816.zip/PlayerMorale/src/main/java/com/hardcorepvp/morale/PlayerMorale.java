package com.hardcorepvp.morale;

import com.hardcorepvp.morale.commands.MoraleCommand;
import com.hardcorepvp.morale.data.MoraleManager;
import com.hardcorepvp.morale.listeners.MoraleListener;
import lombok.Getter;
import org.bukkit.plugin.java.JavaPlugin;

public class PlayerMorale extends JavaPlugin {

    @Getter
    private static PlayerMorale instance;

    @Getter
    private MoraleManager moraleManager;

    @Override
    public void onEnable() {
        instance = this;

        saveDefaultConfig();

        this.moraleManager = new MoraleManager(this);
        this.moraleManager.load();

        getCommand("morale").setExecutor(new MoraleCommand(this));

        getServer().getPluginManager().registerEvents(new MoraleListener(this), this);

        moraleManager.startDecayTask();

        getLogger().info("PlayerMorale enabled!");
    }

    @Override
    public void onDisable() {
        if (moraleManager != null) {
            moraleManager.stopDecayTask();
            moraleManager.save();
        }
        getLogger().info("PlayerMorale disabled!");
    }
}