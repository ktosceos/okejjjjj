package com.hardcorepvp.morale.commands;

import com.hardcorepvp.morale.PlayerMorale;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;

public class MoraleCommand implements CommandExecutor {

    private final PlayerMorale plugin;

    public MoraleCommand(PlayerMorale plugin) {
        this.plugin = plugin;
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (!(sender instanceof Player)) return true;

        Player player = (Player) sender;
        int morale = plugin.getMoraleManager().getMorale(player.getUniqueId());

        String bar = getBar(morale);
        String status = getStatus(morale);

        player.sendMessage("§6§l=== MORALE ===");
        player.sendMessage("§7Level: " + bar + " §e" + morale + "/100");
        player.sendMessage("§7Status: " + status);

        return true;
    }

    private String getBar(int morale) {
        int filled = morale / 10;
        StringBuilder bar = new StringBuilder("§a");

        for (int i = 0; i < 10; i++) {
            if (i < filled) {
                bar.append("█");
            } else {
                bar.append("§7█");
            }
        }

        return bar.toString();
    }

    private String getStatus(int morale) {
        if (morale >= 75) return "§a§lHeroic";
        if (morale >= 50) return "§e§lSteady";
        if (morale >= 25) return "§6§lShaken";
        return "§c§lBroken";
    }
}