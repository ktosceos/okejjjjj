package com.hardcorepvp.morale.listeners;

import com.hardcorepvp.morale.PlayerMorale;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.EntityDamageByEntityEvent;
import org.bukkit.event.entity.PlayerDeathEvent;
import org.bukkit.util.Vector;

public class MoraleListener implements Listener {

    private final PlayerMorale plugin;

    public MoraleListener(PlayerMorale plugin) {
        this.plugin = plugin;
    }

    @EventHandler
    public void onDeath(PlayerDeathEvent event) {
        Player victim = event.getEntity();
        plugin.getMoraleManager().onDeath(victim.getUniqueId());

        Player killer = victim.getKiller();
        if (killer != null) {
            plugin.getMoraleManager().onPvPWin(killer.getUniqueId());
        }
    }

    @EventHandler
    public void onDamage(EntityDamageByEntityEvent event) {
        if (!(event.getDamager() instanceof Player)) return;
        if (!(event.getEntity() instanceof Player)) return;

        Player attacker = (Player) event.getDamager();
        Player victim = (Player) event.getEntity();

        if (plugin.getMoraleManager().shouldPanicBreak(victim.getUniqueId())) {
            Vector knockback = victim.getLocation().toVector().subtract(attacker.getLocation().toVector()).normalize().multiply(2);
            victim.setVelocity(knockback);
            victim.sendMessage("§c§lPANIC!");
        }

        double critBonus = plugin.getMoraleManager().getCritChanceBonus(attacker.getUniqueId());
        if (Math.random() < critBonus) {
            event.setDamage(event.getDamage() * 1.5);
            attacker.sendMessage("§6§lCRITICAL HIT!");
        }
    }
}