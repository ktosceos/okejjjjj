package com.hardcorepvp.upgrade;

import com.hardcorepvp.upgrade.commands.UpgradeCommand;
import com.hardcorepvp.upgrade.gui.GUIListener;
import com.hardcorepvp.upgrade.gui.GUIManager;
import lombok.Getter;
import net.milkbowl.vault.economy.Economy;
import org.bukkit.plugin.RegisteredServiceProvider;
import org.bukkit.plugin.java.JavaPlugin;

public class RiskyItemUpgrade extends JavaPlugin {

    @Getter
    private static RiskyItemUpgrade instance;

    @Getter
    private GUIManager guiManager;

    @Getter
    private Economy economy;

    @Override
    public void onEnable() {
        instance = this;

        if (!setupEconomy()) {
            getLogger().severe("Vault not found! Disabling plugin.");
            getServer().getPluginManager().disablePlugin(this);
            return;
        }

        saveDefaultConfig();

        this.guiManager = new GUIManager();

        getCommand("upgrade").setExecutor(new UpgradeCommand(this));

        getServer().getPluginManager().registerEvents(new GUIListener(guiManager), this);

        getLogger().info("RiskyItemUpgrade enabled!");
    }

    @Override
    public void onDisable() {
        getLogger().info("RiskyItemUpgrade disabled!");
    }

    private boolean setupEconomy() {
        if (getServer().getPluginManager().getPlugin("Vault") == null) {
            return false;
        }

        RegisteredServiceProvider<Economy> rsp = getServer().getServicesManager().getRegistration(Economy.class);
        if (rsp == null) {
            return false;
        }

        economy = rsp.getProvider();
        return economy != null;
    }
}