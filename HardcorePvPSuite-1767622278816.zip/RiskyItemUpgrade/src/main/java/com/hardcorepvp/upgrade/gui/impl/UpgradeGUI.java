package com.hardcorepvp.upgrade.gui.impl;

import com.cryptomorin.xseries.XMaterial;
import com.cryptomorin.xseries.XSound;
import com.cryptomorin.xseries.particles.XParticle;
import com.hardcorepvp.upgrade.RiskyItemUpgrade;
import com.hardcorepvp.upgrade.inventory.InventoryButton;
import com.hardcorepvp.upgrade.inventory.InventoryGUI;
import org.bukkit.Bukkit;
import org.bukkit.entity.Player;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.ThreadLocalRandom;

public class UpgradeGUI extends InventoryGUI {

    private final RiskyItemUpgrade plugin;

    public UpgradeGUI(RiskyItemUpgrade plugin) {
        this.plugin = plugin;
    }

    @Override
    protected Inventory createInventory() {
        return Bukkit.createInventory(null, 27, "§8§lItem Upgrade");
    }

    @Override
    public void decorate(Player player) {
        ItemStack item = player.getInventory().getItemInMainHand();

        if (item == null || item.getType().isAir()) {
            this.addButton(13, new InventoryButton()
                .creator(p -> createInfoItem("§cNo Item", "§7Hold an item to upgrade"))
                .consumer(event -> {})
            );
        } else {
            int currentLevel = getItemLevel(item);
            int maxLevel = plugin.getConfig().getInt("max-level", 10);

            if (currentLevel >= maxLevel) {
                this.addButton(13, new InventoryButton()
                    .creator(p -> createInfoItem("§cMax Level", "§7This item is at max level"))
                    .consumer(event -> {})
                );
            } else {
                int nextLevel = currentLevel + 1;
                int successChance = plugin.getConfig().getInt("levels." + nextLevel + ".success-chance", 50);
                int destroyChance = plugin.getConfig().getInt("levels." + nextLevel + ".destroy-chance", 25);
                double cost = plugin.getConfig().getDouble("levels." + nextLevel + ".cost", 1000);

                this.addButton(13, new InventoryButton()
                    .creator(p -> {
                        ItemStack display = item.clone();
                        ItemMeta meta = display.getItemMeta();
                        List<String> lore = meta.hasLore() ? meta.getLore() : new ArrayList<>();
                        lore.add("");
                        lore.add("§7Current Level: §e" + currentLevel);
                        lore.add("§7Next Level: §e" + nextLevel);
                        lore.add("");
                        lore.add("§aSuccess: §e" + successChance + "%");
                        lore.add("§cDestroy: §e" + destroyChance + "%");
                        lore.add("§7Cost: §e$" + cost);
                        meta.setLore(lore);
                        display.setItemMeta(meta);
                        return display;
                    })
                    .consumer(event -> {})
                );

                this.addButton(11, new InventoryButton()
                    .creator(p -> createUpgradeButton(successChance, destroyChance, cost))
                    .consumer(event -> {
                        Player clicker = (Player) event.getWhoClicked();
                        attemptUpgrade(clicker, item, nextLevel, successChance, destroyChance, cost);
                    })
                );
            }
        }

        super.decorate(player);
    }

    private ItemStack createInfoItem(String name, String... lore) {
        ItemStack item = XMaterial.PAPER.parseItem();
        ItemMeta meta = item.getItemMeta();
        meta.setDisplayName(name);
        meta.setLore(java.util.Arrays.asList(lore));
        item.setItemMeta(meta);
        return item;
    }

    private ItemStack createUpgradeButton(int successChance, int destroyChance, double cost) {
        ItemStack item = XMaterial.EMERALD.parseItem();
        ItemMeta meta = item.getItemMeta();
        meta.setDisplayName("§a§lUPGRADE");
        List<String> lore = new ArrayList<>();
        lore.add("");
        lore.add("§7Click to attempt upgrade");
        lore.add("");
        lore.add("§aSuccess: §e" + successChance + "%");
        lore.add("§cDestroy: §e" + destroyChance + "%");
        lore.add("§7Fail: §e" + (100 - successChance - destroyChance) + "%");
        lore.add("");
        lore.add("§7Cost: §e$" + cost);
        meta.setLore(lore);
        item.setItemMeta(meta);
        return item;
    }

    private void attemptUpgrade(Player player, ItemStack item, int nextLevel, int successChance, int destroyChance, double cost) {
        if (plugin.getEconomy().getBalance(player) < cost) {
            player.sendMessage("§cYou don't have enough money!");
            XSound.matchXSound("ENTITY_VILLAGER_NO").ifPresent(s -> s.play(player));
            return;
        }

        plugin.getEconomy().withdrawPlayer(player, cost);

        int roll = ThreadLocalRandom.current().nextInt(100);

        if (roll < successChance) {
            setItemLevel(item, nextLevel);
            player.getInventory().setItemInMainHand(item);

            String message = plugin.getConfig().getString("messages.success", "Success!")
                .replace("&", "§")
                .replace("{level}", String.valueOf(nextLevel));
            player.sendMessage(message);

            XSound.matchXSound("ENTITY_PLAYER_LEVELUP").ifPresent(s -> s.play(player));
            XParticle.of("VILLAGER_HAPPY").ifPresent(p ->
                player.getWorld().spawnParticle(p.get(), player.getLocation().add(0, 1, 0), 20, 0.5, 0.5, 0.5, 0.1)
            );

        } else if (roll < successChance + destroyChance) {
            player.getInventory().setItemInMainHand(null);

            String message = plugin.getConfig().getString("messages.destroyed", "Destroyed!")
                .replace("&", "§");
            player.sendMessage(message);

            XSound.matchXSound("ENTITY_ITEM_BREAK").ifPresent(s -> s.play(player));
            XParticle.of("SMOKE_LARGE").ifPresent(p ->
                player.getWorld().spawnParticle(p.get(), player.getLocation().add(0, 1, 0), 30, 0.3, 0.3, 0.3, 0.1)
            );

        } else {
            int currentLevel = getItemLevel(item);
            String message = plugin.getConfig().getString("messages.fail", "Failed!")
                .replace("&", "§")
                .replace("{level}", String.valueOf(currentLevel));
            player.sendMessage(message);

            XSound.matchXSound("ENTITY_VILLAGER_NO").ifPresent(s -> s.play(player));
        }

        player.closeInventory();
    }

    private int getItemLevel(ItemStack item) {
        if (item == null || !item.hasItemMeta()) {
            return 0;
        }

        ItemMeta meta = item.getItemMeta();
        if (!meta.hasLore()) {
            return 0;
        }

        for (String line : meta.getLore()) {
            if (line.contains("§7Level: §e")) {
                try {
                    return Integer.parseInt(line.replace("§7Level: §e", "").trim());
                } catch (NumberFormatException e) {
                    return 0;
                }
            }
        }

        return 0;
    }

    private void setItemLevel(ItemStack item, int level) {
        ItemMeta meta = item.getItemMeta();
        List<String> lore = meta.hasLore() ? new ArrayList<>(meta.getLore()) : new ArrayList<>();

        lore.removeIf(line -> line.contains("§7Level: §e"));

        lore.add(0, "§7Level: §e" + level);

        meta.setLore(lore);
        item.setItemMeta(meta);
    }
}